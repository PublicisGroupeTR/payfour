/* eslint-disable react-native/no-inline-styles */
// Example of Splash, Login and Sign Up in React Native
// https://aboutreact.com/react-native-login-and-signup/

// Import React and Component
import React, {useEffect, useState, useRef} from 'react';
import {
  View,
  Text,
  SafeAreaView,
  Image,
  TouchableOpacity,
  FlatList,
  TextInput,
  ScrollView,
  Linking,
  Modal,
  Dimensions,
  StyleSheet,
  Pressable,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {createStackNavigator} from '@react-navigation/stack';
import {SelectList} from 'react-native-dropdown-select-list';

import {styles} from '../Components/Styles.js';
import Loader from '../Components/Loader.js';
import TabHeader from '../Components/TabHeader.js';
import SubtabHeader from '../Components/SubtabHeader.js';
import Bilgi from '../../assets/img/svg/bilgi.svg';
import axios from 'react-native-axios';
import LinearGradient from 'react-native-linear-gradient';
import HTMLView from 'react-native-htmlview';

const Stack = createStackNavigator();

const CampaignList = ({navigation}) => {
  const [loading, setLoading] = useState(false);
  const [campaignData, setCampaignData] = useState(false);
  const scrollRef = useRef();
  const [transactionType, setTransactionType] = React.useState('all');
  const [filterModalVisible, setFilterModalVisible] = useState(false);
  const [orderModalVisible, setOrderModalVisible] = useState(false);
  
  const [isSpecial, setIsSpecial] = useState(false);
  const [isCashback, setIsCashback] = useState(false);
  const [isPartnership, setIsPartnership] = useState(false);
  const [isAward, setIsAward] = useState(false);
  const [isPaymentOfEase, setIsPaymentOfEase] = useState(false);
  const [orderType, setOrderType] = React.useState('DateDescending');

  const [filterType, setFilterType] = React.useState('');

  useEffect(() => {   
    const unsubscribe = navigation.addListener('focus', () => {
      // do something
        getCampaigns(false)
    });
    return unsubscribe;
  }, [navigation]);
  const setFilterData = () =>{
    setFilterModalVisible(false);
    setOrderModalVisible(false);
    let filter = "";
    if(isSpecial) filter+="&isSpecial=true";
    if(isCashback) filter+="&isCashback=true";
    if(isPartnership) filter+="&isPartnership=true";
    if(isAward) filter+="&isAward=true";
    if(isPaymentOfEase) filter+="&isPaymentOfEase=true";
    filter+='&sort='+orderType;
    console.log("filter ? ");
    console.log(filter);
    getCampaigns(false, filter);
  }
  const getCampaigns = (isPayfour, filterList)=>{
    AsyncStorage.getItem('token').then(value =>{
      const config = {
        headers: { Authorization: `Bearer ${value}` }
      };
      let path = 'http://payfourapp.test.kodegon.com/api/campaigns?page=1&pageSize=12';
      if(isPayfour) path+="&isPayfourCampaign=true";
      if(filterList) path+=filterList;
      axios.get(path, config).then(response => {
        console.log(response.data);
        console.log(response.data.data);
        console.log(response.data.data.items);
        let sl = response.data.data.items;
        for(var i=0; i < sl.length;i++){
          sl[i].key = sl[i].campaignCode;
          let dt = new Date(sl[i].expireDate);
          let tdt = new Date();
          console.log(dt.getTime());
          console.log(tdt.getTime());
          console.log(dt.getTime() < tdt.getTime());
          sl[i].expired = (dt.getTime() < tdt.getTime());
          let t = (((dt.getDate()<10)? "0"+dt.getDate() : dt.getDate())) +'.'+(((dt.getMonth()+1)<10)? "0"+(dt.getMonth()+1) :(dt.getMonth()+1))+'.'+dt.getFullYear();
          sl[i].time = t;
        }
        console.log(sl);
        setCampaignData(sl);
        setLoading(false);
        scrollRef.current?.scrollToOffset({ animated: true, offset: 0 });
      })
      .catch(error => {
        console.error("Error sending data: ", error);
        let msg="";
        (error.response.data.errors.message) ? msg += error.response.data.errors.message+"\n" : msg += "Ödeme hatası \n"; (error.response.data.errors.paymentError) ? msg += error.response.data.errors.paymentError+"\n" : msg += ""; Alert.alert(msg);
      });

    });
  }
const Item = ({time, title, refno, img, key, refid, expired}) => (
  <View key={key} style={{...slstyles.slide}}> 
  <TouchableOpacity onPress={() => { 
    

      console.log("campaign click");
      console.log(expired);
      console.log(refid)
      navigation.navigate('campaign', { 
            screen: 'CampaignDetail',
            params: {id: refid}
          })}
        }>
      <View style={{}}>
        <View style={{
          position:'absolute',
          top:0,
          left:0,
          width:'100%',
          height:'100%',
          backgroundColor:expired?  'rgba(0,0,0,0.5)' : 'none',
          zIndex:2,
        }}></View>
        
      <Image 
      source={{
        uri: img,
      }}
      style={[slstyles.slideImg, {
        resizeMode: 'cover',
        
      }]}
    />
    </View>
      <Text style={{
        fontSize:12,
        lineHeight:18,
        color:'#0B1929',
        marginBottom:8,
      }}>
        {title}
      </Text>
      <View style={{
        flexDirection:'row',
        alignItems:'center',
        justifyContent:'flex-start',
      }}>
      <Image 
      source={require('../../assets/img/export/time-oclock.png')}
      style={{
        resizeMode:'contain',
        width:10,
        height:10,
        marginRight:4,
        tintColor: '#28303F',
      }}>
      </Image>
        <Text style={{
          fontSize:10,
          color:'#909EAA',
        }}>
        Son gün {time}
        </Text>
      </View>
  </TouchableOpacity>
  </View>
  );
  const renderCampaigns = () => {
    if (campaignData.length > 0) {
      return (        
        <FlatList
            data={campaignData}
            ref={scrollRef}
            renderItem={({item}) => (
              //time, title, refno, img
              <Item time={item.time} title={item.title} img = {item.thumbnailUrl} refno={item.campaignCode} key={item.campaignCode} refid={item.id} expired={item.expired}/>
            )}
            keyExtractor={item => item.campaignCode}
            style={{paddingLeft: 30,
              paddingRight: 30, marginLeft:-30, marginRight:-30}}
            // onEndReached={setPage}
            initialNumToRender={20}            
          />
      );
    } else {
      return (
        <View
          style={{
            padding: 18,
            height: 54,
            color: '#1D1D25',
          }}>
          <Text
            style={{
              fontSize: 16,
              color: '#0B1929',
              fontWeight: '700',
              paddingLeft: 20,
            }}>
            Kampanya bulunamadı.
          </Text>
        </View>
      );
    }
  };

  return (
    <SafeAreaView style={{flex: 1, backgroundColor: '#fff'}}> 
    <Modal
            animationType="slide"
            transparent={true}
            visible={filterModalVisible}
            onRequestClose={() => {
              setFilterModalVisible(!filterModalVisible);
            }}>
            <View
              style={{
                flex: 1,                
                justifyContent: 'flex-end',
                alignItems: 'flex-end',
                backgroundColor: 'rgba(92, 92, 92, 0.56)',
              }}>
              <View
                style={{
                  backgroundColor:'#fff',
                  borderTopLeftRadius: 24,
                  borderTopRightRadius: 24,
                  paddingTop: 30,
                  paddingBottom: 16,
                  paddingLeft: 16,
                  paddingRight: 16,
                  width: '100%',
                }}>
                  <View style={{
                    flexDirection:'row',
                    justifyContent:'space-between',
                    alignItems:'center',
                    marginBottom:16,
                  }}>
                    <Text style={{
                      fontSize:14,
                      lineHeight:16,
                      color:'#004F97',
                    }}>
                      Filtrele
                    </Text>
                    <TouchableOpacity 
                      style={{
                        width:24,
                        height:24,
                      }}
                      onPress={() => {
                        console.log('close');
                        setFilterModalVisible(false);}}>                  
                        <Image 
                        source={require('../../assets/img/export/close.png')}
                        style={{
                          width: 24,
                          height: 24,
                          resizeMode: 'contain',
                        }}
                      />
                    </TouchableOpacity>
                  </View>
                  <View style={{
                    flexDirection:'row',
                    justifyContent:'space-between',
                    alignItems:'center',
                    marginBottom:16,
                    paddingTop:24,
                    paddingBottom:24,
                    borderTopWidth:1,
                    borderTopColor:'#E4E4E8',
                    borderBottomWidth:1,
                    borderBottomColor:'#E4E4E8',
                  }}>
                    <Text style={{
                      fontSize:16,
                      lineHeight:16,
                      color:'#004F97',
                    }}>
                      Payfour'a özel
                    </Text>
                    <Text style={{
                      fontSize:14,
                      lineHeight:16,
                      color:'#909EAA',
                    }}>
                      Tümü
                    </Text>
                    
                  </View>
                  <View style={{
                      marginBottom:24,
                      alignItems:'center',
                      flexDirection:'row'
                    }}>
                      <Pressable
                        style={{
                          width:24,
                          height:24,
                          marginRight:8,
                          backgroundColor:isSpecial ? '#015096':'#fff',
                          borderWidth:1, 
                          borderColor:'#DADEE7',
                          borderRadius:5,
                          alignItems:'center',
                          justifyContent:'center'
                        }}
                        onPress={()=> setIsSpecial(!isSpecial)}>
                        <Image
                          source={require('../../assets/img/export/check.png')}
                          style={{
                            width: isSpecial ? 14 : 0,
                            height: isSpecial ? 10 : 0,
                            resizeMode: 'contain',
                          }}
                        />
                      </Pressable>
                      
                      <Text style={{
                        fontSize:14,fontWeight:'700', color:'#0B1929', marginBottom:4
                      }}>
                      Sana Özel
                      </Text>
                    </View>
                    <View style={{
                      marginBottom:24,
                      alignItems:'center',
                      flexDirection:'row'
                    }}>
                      <Pressable
                        style={{
                          width:24,
                          height:24,
                          marginRight:8,
                          backgroundColor:isCashback ? '#015096':'#fff',
                          borderWidth:1, 
                          borderColor:'#DADEE7',
                          borderRadius:5,
                          alignItems:'center',
                          justifyContent:'center'
                        }}
                        onPress={()=> setIsCashback(!isCashback)}>
                        <Image
                          source={require('../../assets/img/export/check.png')}
                          style={{
                            width: isCashback ? 14 : 0,
                            height: isCashback ? 10 : 0,
                            resizeMode: 'contain',
                          }}
                        />
                      </Pressable>
                      
                      <Text style={{
                        fontSize:14,fontWeight:'700', color:'#0B1929', marginBottom:4
                      }}>
                      Cashback Kampanyaları
                      </Text>
                    </View>
                    <View style={{
                      marginBottom:24,
                      alignItems:'center',
                      flexDirection:'row'
                    }}>
                      <Pressable
                        style={{
                          width:24,
                          height:24,
                          marginRight:8,
                          backgroundColor:isPartnership ? '#015096':'#fff',
                          borderWidth:1, 
                          borderColor:'#DADEE7',
                          borderRadius:5,
                          alignItems:'center',
                          justifyContent:'center'
                        }}
                        onPress={()=> setIsPartnership(!isPartnership)}>
                        <Image
                          source={require('../../assets/img/export/check.png')}
                          style={{
                            width: isPartnership ? 14 : 0,
                            height: isPartnership ? 10 : 0,
                            resizeMode: 'contain',
                          }}
                        />
                      </Pressable>
                      
                      <Text style={{
                        fontSize:14,fontWeight:'700', color:'#0B1929', marginBottom:4
                      }}>
                      İş Birlikleri
                      </Text>
                    </View>
                    <View style={{
                      marginBottom:24,
                      alignItems:'center',
                      flexDirection:'row'
                    }}>
                      <Pressable
                        style={{
                          width:24,
                          height:24,
                          marginRight:8,
                          backgroundColor:isAward ? '#015096':'#fff',
                          borderWidth:1, 
                          borderColor:'#DADEE7',
                          borderRadius:5,
                          alignItems:'center',
                          justifyContent:'center'
                        }}
                        onPress={()=> setIsAward(!isAward)}>
                        <Image
                          source={require('../../assets/img/export/check.png')}
                          style={{
                            width: isAward ? 14 : 0,
                            height: isAward ? 10 : 0,
                            resizeMode: 'contain',
                          }}
                        />
                      </Pressable>
                      
                      <Text style={{
                        fontSize:14,fontWeight:'700', color:'#0B1929', marginBottom:4
                      }}>
                      Puan Kampanyaları
                      </Text>
                    </View>
                    <View style={{
                      marginBottom:24,
                      alignItems:'center',
                      flexDirection:'row'
                    }}>
                      <Pressable
                        style={{
                          width:24,
                          height:24,
                          marginRight:8,
                          backgroundColor:isPaymentOfEase ? '#015096':'#fff',
                          borderWidth:1, 
                          borderColor:'#DADEE7',
                          borderRadius:5,
                          alignItems:'center',
                          justifyContent:'center'
                        }}
                        onPress={()=> setIsPaymentOfEase(!isPaymentOfEase)}>
                        <Image
                          source={require('../../assets/img/export/check.png')}
                          style={{
                            width: isPaymentOfEase ? 14 : 0,
                            height: isPaymentOfEase ? 10 : 0,
                            resizeMode: 'contain',
                          }}
                        />
                      </Pressable>
                      
                      <Text style={{
                        fontSize:14,fontWeight:'700', color:'#0B1929', marginBottom:4
                      }}>
                      Ödeme Kolaylığı Kampanyaları
                      </Text>
                    </View>
                  
                  <TouchableOpacity
                    style={[
                      styles.buttonStyle,
                      {
                        width: '100%',
                        height: 52,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        borderWidth: 2,
                        borderColor: '#004F97',
                        backgroundColor: '#004F97',
                        padding:0,
                        marginTop:60,
                      },
                    ]}
                    onPress={() => setFilterData()}>
                    <Text
                      style={{fontSize: 14, color: '#ffffff'}}>
                      Kampanyaları Göster
                    </Text>
                  </TouchableOpacity>
               
              </View>
            </View>
      </Modal>  
      <Modal
            animationType="slide"
            transparent={true}
            visible={orderModalVisible}
            onRequestClose={() => {
              setOrderModalVisible(!orderModalVisible);
            }}>
            <View
              style={{
                flex: 1,                
                justifyContent: 'flex-end',
                alignItems: 'flex-end',
                backgroundColor: 'rgba(92, 92, 92, 0.56)',
              }}>
              <View
                style={{
                  backgroundColor:'#fff',
                  borderTopLeftRadius: 24,
                  borderTopRightRadius: 24,
                  paddingTop: 30,
                  paddingBottom: 16,
                  paddingLeft: 16,
                  paddingRight: 16,
                  width: '100%',
                }}>
                  <View style={{
                    flexDirection:'row',
                    justifyContent:'space-between',
                    alignItems:'center',
                    marginBottom:16,
                  }}>
                    <Text style={{
                      fontSize:14,
                      lineHeight:16,
                      color:'#004F97',
                    }}>
                      Sırala
                    </Text>
                    <TouchableOpacity 
                      style={{
                        width:24,
                        height:24,
                      }}
                      onPress={() => {
                        console.log('close');
                        setOrderModalVisible(false);}}>                  
                        <Image 
                        source={require('../../assets/img/export/close.png')}
                        style={{
                          width: 24,
                          height: 24,
                          resizeMode: 'contain',
                        }}
                      />
                    </TouchableOpacity>
                  </View>
                  
                  <TouchableOpacity style={{
                    flexDirection:'row',
                    alignItems:'center',
                    paddingTop:8,
                    paddingBottom:8,
                    backgroundColor: orderType === 'DateDescending' ? '#F2F4F6' : '#fff'
                  }}
                  onPress={()=>{
                    setOrderType('DateDescending');
                    console.log(orderType)
                    }}>
                    <View style={{
                      width:24, height:24, borderRadius:24, borderWidth:1, borderColor:'#004F97', marginRight:8,
                    }}
                    onPress={() => {
                      setOrderType('DateDescending');
                      console.log(orderType)
                      }}>
                        
                      <View style={{
                        width:12, 
                        height:12, 
                        borderRadius:12, 
                        backgroundColor:'#004F97', 
                        position:'absolute', 
                        top:5, 
                        left:5,
                        display: orderType === 'DateDescending' ? 'flex' : 'none'}}></View>
                    </View>
                      <Text style={{
                        fontSize:16,fontWeight:'700', color:'#004F97', marginBottom:4
                      }}>
                      Tarihe göre en yeni
                      </Text>
                      
                  </TouchableOpacity>
                  <TouchableOpacity style={{
                    flexDirection:'row',
                    alignItems:'center',
                    paddingTop:8,
                    paddingBottom:8,
                    backgroundColor: orderType === 'DateAscending' ? '#F2F4F6' : '#fff'
                  }}
                  onPress={()=>{
                    setOrderType('DateAscending');
                    console.log(orderType);
                  }
                  }>
                    <View style={{
                      width:24, height:24, borderRadius:24, borderWidth:1, borderColor:'#004F97', marginRight:8,
                    }}
                    onPress={() => {
                      setOrderType('DateAscending');
                      console.log(orderType);
                      }}>
                        
                      <View style={{
                        width:12, 
                        height:12, 
                        borderRadius:12, 
                        backgroundColor:'#004F97', 
                        position:'absolute', 
                        top:5, 
                        left:5,
                        display: orderType === 'DateAscending' ? 'flex' : 'none'}}></View>
                    </View>
                      <Text style={{
                        fontSize:16,fontWeight:'700', color:'#004F97', marginBottom:4
                      }}>
                      Tarihe göre en eski
                      </Text>
                      
                  </TouchableOpacity>
                  <TouchableOpacity style={{
                    flexDirection:'row',
                    alignItems:'center',
                    paddingTop:8,
                    paddingBottom:8,
                    backgroundColor: orderType === 'BrandAscending' ? '#F2F4F6' : '#fff'
                  }}
                  onPress={()=>setOrderType('BrandAscending')}>
                    <View style={{
                      width:24, height:24, borderRadius:24, borderWidth:1, borderColor:'#004F97', marginRight:8,
                    }}
                    onPress={() => {
                      setOrderType('BrandAscending');
                      }}>
                        
                      <View style={{
                        width:12, 
                        height:12, 
                        borderRadius:12, 
                        backgroundColor:'#004F97', 
                        position:'absolute', 
                        top:5, 
                        left:5,
                        display: orderType === 'BrandAscending' ? 'flex' : 'none'}}></View>
                    </View>
                      <Text style={{
                        fontSize:16,fontWeight:'700', color:'#004F97', marginBottom:4
                      }}>
                      Markalara göre A-Z
                      </Text>
                      
                  </TouchableOpacity>
                  <TouchableOpacity style={{
                    flexDirection:'row',
                    alignItems:'center',
                    paddingTop:8,
                    paddingBottom:8,
                    backgroundColor: orderType === 'BrandDescending' ? '#F2F4F6' : '#fff'
                  }}
                  onPress={()=>setOrderType('BrandDescending')}>
                    <View style={{
                      width:24, height:24, borderRadius:24, borderWidth:1, borderColor:'#004F97', marginRight:8,
                    }}
                    onPress={() => {
                      setOrderType('BrandDescending');
                      }}>
                        
                      <View style={{
                        width:12, 
                        height:12, 
                        borderRadius:12, 
                        backgroundColor:'#004F97', 
                        position:'absolute', 
                        top:5, 
                        left:5,
                        display: orderType === 'BrandDescending' ? 'flex' : 'none'}}></View>
                    </View>
                      <Text style={{
                        fontSize:16,fontWeight:'700', color:'#004F97', marginBottom:4
                      }}>
                      Markalara göre Z-A
                      </Text>
                      
                  </TouchableOpacity>
                  
                  <TouchableOpacity
                    style={[
                      styles.buttonStyle,
                      {
                        width: '100%',
                        height: 52,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        borderWidth: 2,
                        borderColor: '#004F97',
                        backgroundColor: '#004F97',
                        padding:0,
                        marginTop:60,
                      },
                    ]}
                    onPress={() => setFilterData()}>
                    <Text
                      style={{fontSize: 14, color: '#ffffff'}}>
                      Kampanyaları Göster
                    </Text>
                  </TouchableOpacity>
               
              </View>
            </View>
      </Modal>    
      <Loader loading={loading} />
      <SubtabHeader routetarget="discover" name="Kampanyalar" count="0" />
      <LinearGradient colors={['#fcfcfd', '#fbfbfd']} 
      style={{
        position:'absolute',
        width:'100%',
        height:'100%',
        top:60,
        zIndex:0,
        
      }}
      >
  
      </LinearGradient>
      <View style={{padding:16,}}>
        <View style={{borderRadius:16}}>          
          <View style={{
            padding:8,
            borderRadius:8,
            backgroundColor:'#fff',
            flexDirection:'row',
            justifyContent:'space-between',
            alignItems:'center',
            width:'100%',
            shadowColor: "#000",
            shadowOffset: {
              width: 0,
              height: 1,
            },
            shadowOpacity: 0.15,
            shadowRadius: 3.84,
            elevation: 8,
          }}>
            <TouchableOpacity 
            style={{
              alignItems:'center', 
              justifyContent:'center',
              borderRadius:8,
              height:46,
              width:'50%',
              backgroundColor: transactionType==='all'? '#004F97' : '#fff',
            }}
            onPress={()=>{
              setTransactionType('all');
              getCampaigns(false);
            }}
            >
              <Text style={{
                fontSize:12,
                color: transactionType==='all'? '#fff':'#909EAA',
              }}
              >
                Tümü
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity 
            style={{
              alignItems:'center', 
              justifyContent:'center',
              borderRadius:8,
              height:46,
              width:'50%',
              backgroundColor: transactionType==='special'? '#004F97' : '#fff',
            }}
            onPress={()=>{
              setTransactionType('special');
              getCampaigns(true);
            }}
            >
              <Text style={{
                fontSize:12,
                color: transactionType==='special'? '#fff':'#909EAA',
              }}
              >
                Payfour'a Özel
              </Text>
            </TouchableOpacity>            

          </View>
          
        </View>
      </View>
      <View style={{
        backgroundColor:'#fff',
        flexDirection:'row',
        alignItems:'center',
        justifyContent:'center',
        paddingLeft:16,
        paddingRight:16,
      }}>
        <TouchableOpacity 
            style={{
              alignItems:'center', 
              justifyContent:'center',
              flexDirection:'row',
              borderRadius:8,
              height:46,
              width:'50%',
              backgroundColor:'#fff',
            }}
            onPress={()=>{
              setFilterModalVisible(true);
            }}
            >
              <Text style={{
                fontSize:14,
                color: '#909EAA',
                marginRight:16,
              }}
              >
                Filtrele
              </Text>
              <Image 
              source={require('../../assets/img/export/icon_filter.png')}
              style={{
                resizeMode:'contain',
                width:24,
                height:24,
              }}></Image>
            </TouchableOpacity>
            <View style={{width:1,height:24, backgroundColor:'#E4E4E8',}}></View>
            <TouchableOpacity 
            style={{
              alignItems:'center', 
              justifyContent:'center',
              flexDirection:'row',
              borderRadius:8,
              height:46,
              width:'50%',
              backgroundColor: '#fff',
            }}
            onPress={()=>{
              setOrderModalVisible(true);
            }}
            >
              <Text style={{
                fontSize:14,
                color: '#909EAA',
                marginRight:16,
              }}
              >
                Sırala
              </Text>
              <Image 
              source={require('../../assets/img/export/icon_order.png')}
              style={{
                resizeMode:'contain',
                width:24,
                height:24,
              }}></Image>
            </TouchableOpacity>
      </View>
      <View style={{
        paddingTop:12,
        paddingBottom:100,
        paddingLeft:16,
        paddingRight:16,
        flex:1,
        width:'100%',
      }}
      >
        {renderCampaigns()} 
      </View>  
         
    </SafeAreaView>
  );

}
const CampaignDetail = ({navigation, route}) => {
  const [loading, setLoading] = useState(false);
  const [showMore, setShowMore] = useState(false);
  const [joined, setJoined] = useState(false);
  const [campaignDetailData, setCampaignDetailData] = useState({title:'', longDescription:'', imageUrl:'', time:''});
  const [modalVisible, setModalVisible] = useState(false);
  const [rulesModalVisible, setRulesModalVisible] = useState(false);
  const [isAllStores, setIsAllStores] = useState(false);
  useEffect(() => {   
    const unsubscribe = navigation.addListener('focus', () => {
      // do something
      console.log('campaign detail');
      console.log(navigation);
      console.log(route);
      console.log(route.params);
      console.log(route.params.id);
      //console.log(Dimensions.get('window').width);
      console.log('http://payfourapp.test.kodegon.com/api/campaigns/'+route.params.id)
        AsyncStorage.getItem('token').then(value =>{
          const config = {
            headers: { Authorization: `Bearer ${value}` }
          }          
          axios.get('http://payfourapp.test.kodegon.com/api/campaigns/'+route.params.id, config).then(response => {
            //console.log(response.data);
            console.log(response.data.data);
            

            let sl = response.data.data;
            let dt = new Date(sl.expireDate);
            let t = (((dt.getDate()<10)? "0"+dt.getDate() : dt.getDate())) +'.'+(((dt.getMonth()+1)<10)? "0"+(dt.getMonth()+1) :(dt.getMonth()+1))+'.'+dt.getFullYear();
            sl.time = t;
            console.log("title :" +sl.title);
            const re = /<p>/gi;
            const re2 = /<\/p>/gi;
            sl.longDescription = sl.longDescription.replace(re, "<div>");
            sl.longDescription = sl.longDescription.replace(re2, "</div>");
            sl.howTo = sl.howTo.replace(re, "<div>");
            sl.howTo = sl.howTo.replace(re2, "</div>");
            sl.terms = sl.terms.replace(re, "<div>");
            sl.terms = sl.terms.replace(re2, "</div>");
            console.log(sl.longDescription);
            console.log(sl.howTo);
            console.log(sl.terms);
            setCampaignDetailData(sl);
            setIsAllStores(sl.isAllStores);
            /*if(response.data.data.balance != null){
              let b = parseFloat(response.data.data.balance).toFixed(2).replace('.', ',');
              setBalance(b);
            }
            setLoading(false);
            checkCampaigns();*/
          })
          .catch(error => {
            console.error("Error sending data: ", error);
            let msg="";
            (error.response.data.errors.message) ? msg += error.response.data.errors.message+"\n" : msg += "Ödeme hatası \n"; (error.response.data.errors.paymentError) ? msg += error.response.data.errors.paymentError+"\n" : msg += ""; Alert.alert(msg);
          })        });
      
    });
    return unsubscribe;
  }, [route.params?.id]);
  return (
    <SafeAreaView style={{flex: 1, backgroundColor: '#fff'}}>
      <Modal
            animationType="slide"
            transparent={true}
            visible={rulesModalVisible}
            onRequestClose={() => {
              setRulesModalVisible(!rulesModalVisible);
            }}>
            <View
              style={{
                flex: 1,                
                justifyContent: 'flex-end',
                alignItems: 'flex-end',
                backgroundColor: 'rgba(0, 0, 0, 0.6)',
              }}>
              <View
                style={{
                  backgroundColor:'#fff',
                  borderTopLeftRadius: 24,
                  borderTopRightRadius: 24,
                  paddingTop: 33,
                  paddingLeft: 16,
                  paddingRight: 16,
                  width: '100%',
                }}>
                  <View style={{
                      flexDirection:'row',
                      justifyContent:'space-between',
                      }}>
                        <Text style={{
                          fontSize:14,
                          fontWeight:'700',
                          color:'#004F97',
                          lineHeight:20,
                          textAlign:'left',
                          marginBottom:24,
                        }}>
                          Kampanya Kuralları
                        </Text>
                        <TouchableOpacity 
                      style={{
                        width:24,
                        height:24,
                      }}
                      onPress={() => {
                        console.log('close');
                        setRulesModalVisible(false);}}>                  
                        <Image 
                        source={require('../../assets/img/export/close.png')}
                        style={{
                          width: 24,
                          height: 24,
                          resizeMode: 'contain',
                        }}
                      />
                    </TouchableOpacity>
                       </View> 
                <View style={{marginBottom:24}}>
                        <Text style={{
                          fontSize:12,
                          fontWeight:'700',
                          color:'#004F97',
                          marginBottom:8
                        }}>
                          Nasıl Katılırım ?
                        </Text>
                        <HTMLView
                        value={campaignDetailData.howTo}
                        stylesheet={htmlStyles}
                      />     
               
                      </View>
                      <View style={{paddingBottom:18}}>
                        <Text style={{
                          fontSize:12,
                          fontWeight:'700',
                          color:'#004F97',
                          marginBottom:8
                        }}>
                          Ne Kazanırım ?
                        </Text>
                        <HTMLView
                          value={campaignDetailData.terms}
                          stylesheet={htmlStyles}
                        />   
                      </View>
                  </View>
                  
               
              <View style={{
                  backgroundColor:'#fff',
                  paddingTop:24,
                  paddingBottom:24,
                  paddingLeft:16,
                  paddingRight:16,
                  width:'100%',
                  shadowColor: "#000",
                  shadowOffset: {
                    width: 0,
                    height: 15,
                  },
                  shadowOpacity: 1,
                  shadowRadius: 30,                  
                  elevation: 18,
                }}>
                <TouchableOpacity
                  style={[
                    styles.buttonStyle,
                    {
                      width: '100%',
                      height: 52,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      borderWidth: 2,
                      borderColor: '#004F97',
                      backgroundColor: '#004F97',
                      padding:0,
                      elevation:1,
                    },
                  ]}
                  onPress={() => setRulesModalVisible(false)}>
                  <Text
                    style={{fontSize: 14, color: '#ffffff'}}>
                    Kapat
                  </Text>
                </TouchableOpacity>
               </View>
            </View>
      </Modal>
      <Loader loading={loading} />      
      
      <SubtabHeader routetarget={route.params.source? "discover" : "CampaignList"} name="Kampanya Detayı" count="0" />

      <ScrollView
        keyboardShouldPersistTaps="handled"
        style={[styles.scrollView, {width: '100%', }]}>
        <View style={{paddingBottom:120}}>
          <View
            style={{
              alignItems: 'center',
              justifyContent: 'center',
              marginBottom: 22,
            }}>
            <Image
              source={{uri: campaignDetailData =={} ? '' : campaignDetailData.imageUrl}}
              style={{
                width: '100%',
                height:Dimensions.get('window').width*0.466
              }}
              resizeMode={'cover'}
            />
          </View> 
          <View
            style={{
              flex: 1,
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'flex-start',
              paddingTop: 16,
              paddingLeft: 16,
              paddingRight: 16,
              width: '100%',
              paddingBottom: 12,
            }}>
              <View style={{
                flexDirection:'row',
                alignItems:'center',
                justifyContent:'space-between',
                marginBottom:12,
                width:'100%',
              }}>
              <Text style={{
                fontSize:16,
                fontWeight:'500',
                color:'#28303F',
                paddingRight:16,
                textAlign:'left',
              }}>{campaignDetailData.title}</Text>
                <TouchableOpacity style={{}}>
                  <Image
                    source={require('../../assets/img/export/campaign_detail_icon2.png')}
                    style={{
                      width: 32,
                      height:32
                    }}
                />
                </TouchableOpacity>
            </View>
            <View style={{
                display:'flex',
                width:'100%',
                flexDirection:'row',
                alignItems:'center',
                justifyContent:'space-between',
                marginBottom:12,
              }}>
                <View style={{
                  flexDirection:'row',
                  alignItems:'center',
                }}>
                  <Image
                    source={require('../../assets/img/export/time-oclock.png')}
                    style={{
                      width: 10,
                      height:10,
                      marginRight:8,
                    }}
                  />
                  <Text style={{fontSize:10, color:'#004F97'}}>Son gün {campaignDetailData.time}</Text>
                </View>
                <View style={{
                  height:20,
                  paddingLeft:8,
                  paddingRight:8,
                  borderRadius:4,
                  alignItems:'center',
                  justifyContent:'center',
                  backgroundColor:'#FFF4CD'}}>
                  <Text style={{fontSize:12, fontWeight:500, color:'#FFA908'}}>Son 10 Gün</Text>
                </View>
              </View>
            <View style={{marginBottom:12}}>
              {/* 1 Nisan - 15 Mayıs 2024 tarihleri arasında, Payfour anlaşmalı Shell istasyonlarından tek seferde ve farklı günlerde gerçekleştirilecek 
              <Text style={{fontSize:12, color:'#0B1929', fontWeight:'700'}}>750 TL ve üzeri 4. akaryakıt ya da otogaz alışverişine,</Text> Payfour anlaşmalı Shell istasyonlarından yapılacak yakıt alışverişlerinde kullanılmak üzere 400 TL CarrefourSA Puan! */}
              <HTMLView
                value={campaignDetailData.longDescription}
                stylesheet={htmlStyles}
              /> 
              <View style={{display: showMore ? 'flex':'none', fontSize:12, color:'#909EAA'}}>
                <HTMLView
                value={campaignDetailData.howTo}
                stylesheet={htmlStyles}
              />     
               <HTMLView
                value={campaignDetailData.terms}
                stylesheet={htmlStyles}
              />
                </View>
            </View>
            <View style={{width:'100%', marginBottom:12}}>
              <TouchableOpacity 
              style={{justifyContent:'flex-start'}}
              onPress={()=> showMore?setShowMore(false):setShowMore(true)}
              >
              <Text style={{fontSize:12, color:'#004F97', textAlign:'left'}}>Daha fazla göster</Text>
              </TouchableOpacity>
            </View>          
          </View>
          <View
            style={{
              alignItems: 'center',
              justifyContent: 'center',
              marginBottom: 22,
            }}>
            <Image
              source={require('../../assets/img/export/campaign_map.png')}
              style={{
                width: '100%',
                height:Dimensions.get('window').width*0.533
              }}
              resizeMode={'cover'}
            />
            <TouchableOpacity style={{
              position:'absolute',
              bottom:16,
              width:198,
              height:40,
              borderRadius:6,
              borderWidth:1,
              borderColor:'#004F97',
              backgroundColor:'#fff',
              alignItems:'center',
              justifyContent:'center',
              flexDirection:'row', 
              display:isAllStores? 'flex' : 'none'           
              }}>
                <Image
                  source={require('../../assets/img/export/map-location.png')}
                  style={{
                    width: 16,
                    height:16,
                    marginRight:4
                  }}
                />
                <Text style={{fontSize:12, color:'#004F97', fontWeight:'500'}}>Geçerli Şubeler için Tıkla</Text>
            </TouchableOpacity>
          </View> 
          <View style={{paddingLeft:16, paddingRight:16}}>
          <TouchableOpacity
          style={{
            marginBottom:12,
            borderWidth:1,
            borderColor:'#004F97',
            borderRadius:8,
            width:'100%',
            height:52,
            marginBottom:16,
            flexDirection:'row',
            alignItems:'center',
            justifyContent:'center',
            backgroundColor: joined? '#004F97' : '#fff',
          }}
          onPress={()=> joined?setJoined(false):setJoined(true)}>
            <Image
              source={require('../../assets/img/export/checkmark.png')}
              style={{
                width: 24,
                height:24,
                marginRight:8,
                display:joined?'flex':'none',
              }}
            />
            <Text style={{
              fontSize:14, 
              fontWeight:500, 
              color:joined?'#fff' : '#004F97'}}>
              {joined?  'Katıldın': 'Kampanyaya Katıl'}
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={{
              width:'100%',
              height:48,
              alignItems:'center',
              justifyContent:'center',
            }}
            onPress={()=> setRulesModalVisible(true)}>
            <Text style={{
              fontSize:14, 
              fontWeight:500, 
              color:'#004F97'
            }}>
              Kampanya Kuralları
            </Text>
          </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const CampaignScreen = ({navigation}) => {
  

  return (
    <Stack.Navigator initialRouteName="CampaignList">
      <Stack.Screen
        name="CampaignList"
        component={CampaignList}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="CampaignDetail"
        component={CampaignDetail}
        options={{headerShown: false}}
      />
      
    </Stack.Navigator>
  );
};
const slstyles = {
  slider: {
    backgroundColor: 'transparent',
    overflow: 'hidden',
    width: '100%',
    height: Dimensions.get('window').width*0.492,
  },
  slide: {
    width: '100%',
    paddingTop:12,
    paddingBottom:16,
    paddingLeft:16,
    paddingRight:16,
    // alignItems: 'center',
    // justifyContent: 'center',

    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
    backgroundColor:'#fff',
    borderRadius:8,
    marginBottom:16,
  },
  slideImg:{
    width: '100%',
    height:Dimensions.get('window').width*0.5,
    borderRadius:4,
    marginBottom:16,
  },
  text: {
    color: 'white',
    fontSize: 30,
  },
}
const htmlStyles = StyleSheet.create({
  marginBottom:0,
  paddingBottom:0,
  p: {
    margin:0,padding:0,
  },
  div:{
    marginBottom:8,
  },
});
export default CampaignScreen;
