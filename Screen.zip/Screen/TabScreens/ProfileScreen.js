/* eslint-disable react-native/no-inline-styles */
// Example of Splash, Login and Sign Up in React Native
// https://aboutreact.com/react-native-login-and-signup/

// Import React and Component
import React, {useEffect, useState} from 'react';
import {
  View,
  Text,
  SafeAreaView,
  Image,
  TouchableOpacity,
  TextInput,
  ScrollView,
  Linking,
  Modal,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {createStackNavigator} from '@react-navigation/stack';
import {SelectList} from 'react-native-dropdown-select-list';

import {styles} from '../Components/Styles.js';
import Loader from '../Components/Loader';
import TabHeader from '../Components/TabHeader';
import Bildirim from '../../assets/img/svg/bildirim.svg';
import Profil from '../../assets/img/svg/profil.svg';
import Banka from '../../assets/img/svg/banka.svg';
import Bilgi from '../../assets/img/svg/bilgi.svg';
import Sartlar from '../../assets/img/svg/sartlar.svg';
import Iletisim from '../../assets/img/svg/iletisim.svg';
import Cikis from '../../assets/img/svg/cikis.svg';

import Email from '../../assets/img/svg/email.svg';
import Whatsapp from '../../assets/img/svg/whatsapp.svg';

const Stack = createStackNavigator();

const Profile = ({navigation}) => {
  const [userName, setUserName] = useState('');
  const [userDate, setUserDate] = useState('');
  const [userId, setUserId] = useState('');
  const [loading, setLoading] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);

  const getProfile = async obj => {
    console.log(obj);
    setLoading(true);
    const response = await fetch(
      'https://gelirortaklari.api.hasoffers.com/Apiv3/json?api_key=' +
        obj.token +
        '&Target=Affiliate_AffiliateUser&Method=findById&id=' +
        obj.id,
    );
    const json = await response.json();
    //console.log(json);
    console.log(json.response.data.AffiliateUser);
    setUserName(
      json.response.data.AffiliateUser.first_name +
        ' ' +
        json.response.data.AffiliateUser.last_name,
    );
    let d = new Date(json.response.data.AffiliateUser.join_date);
    let day = d.getDate() < 10 ? '0' + d.getDate() : d.getDate();
    let mo =
      d.getMonth() + 1 < 10 ? '0' + (d.getMonth() + 1) : d.getMonth() + 1;
    setUserDate(day + '.' + mo + '.' + d.getFullYear());
    setUserId(json.response.data.AffiliateUser.affiliate_id);
    setLoading(false);
  };
  const handleExit = () => {
    console.log('handleExit');

    setModalVisible(true);
  };
  const logOut = () => {
    AsyncStorage.setItem('userId', '');
    AsyncStorage.setItem('affiliateId', '');
    AsyncStorage.setItem('auth_token', '');
    console.log(navigation.getParent());
    setModalVisible(false);
    navigation.navigate('Auth', {
      screen: 'LoginScreen',
    });
  };

  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', () => {
      // do something
      console.log('Hello World!');
      var obj = {};
      AsyncStorage.getItem('auth_token').then(token =>
        //navigation.replace(value === null ? 'Auth' : 'TabNavigationRoutes'),
        {
          obj.token = token;
          AsyncStorage.getItem('userId').then(id => {
            obj.id = id;
            getProfile(obj);
          });
        },
      );
    });
    return unsubscribe;
  }, [navigation]);
  return (
    <SafeAreaView style={{flex: 1, backgroundColor: '#fff'}}>
      <Loader loading={loading} />
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => {
          //Alert.alert('Modal has been closed.');
          setModalVisible(!modalVisible);
        }}>
        <View
          style={{
            flex: 1,
            justifyContent: 'center',
            alignItems: 'center',
            backgroundColor: 'rgba(92, 92, 92, 0.56)',
            paddingLeft: 48,
            paddingRight: 48,
          }}>
          <View
            style={{
              backgroundColor: '#ffffff',
              borderRadius: 10,
              paddingTop: 41,
              paddingBottom: 49,
              paddingLeft: 36,
              paddingRight: 36,
              width: '100%',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
            }}>
            <Bilgi width={27} height={27} style={{marginBottom: 24}} />
            {/* <Image
              source={require('../../assets/img/info.png')}
              style={{
                width: 27,
                height: 27,
                marginBottom: 24,
              }}
            /> */}
            <Text
              style={{
                fontSize: 18,
                fontWeight: '700',
                color: '#1D1D25',
                marginBottom: 18,
              }}>
              Uyarı
            </Text>
            <Text
              style={{
                fontSize: 14,
                fontWeight: '400',
                color: '#1D1D25',
                marginBottom: 33,
              }}>
              Uygulamadan çıkış yapmak istediğinize emin misiniz?
            </Text>
            <TouchableOpacity
              style={[
                styles.buttonStyle,
                {
                  width: '100%',
                  height: 55,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  marginBottom: 15,
                },
              ]}
              activeOpacity={0.5}
              onPress={logOut}>
              <Text style={{fontSize: 16, fontWeight: '700', color: '#ffffff'}}>
                ÇIKIŞ YAP
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                styles.buttonStyle,
                {
                  width: '100%',
                  height: 55,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  borderWidth: 2,
                  borderColor: '#1D1D25',
                  backgroundColor: '#ffffff',
                },
              ]}
              onPress={() => setModalVisible(!modalVisible)}>
              <Text style={{fontSize: 16, fontWeight: '700', color: '#1D1D25'}}>
                VAZGEÇ
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
      {/* <View style={styles.topStyle}>
        <View style={{alignItems: 'center'}}>
          <Text style={styles.headerTextStyle}>Profilim</Text>
        </View>
        <View style={styles.notificationIcon}>
          <View style={styles.notificationImg}>
            <Image
              source={require('../../assets/img/bildirim.png')}
              style={{
                width: 18,
                height: 21,
              }}
            />
          </View>
          <View style={styles.notificationNumber}>
            <Text style={styles.notificationText}>1</Text>
          </View>
        </View>
      </View> */}
      <TabHeader routetarget="" name="Profilim" count="0" />

      <ScrollView
        keyboardShouldPersistTaps="handled"
        style={[styles.scrollView, {width: '100%'}]}>
        <View
          style={{
            flex: 1,
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'flex-start',
            paddingTop: 27,
            paddingLeft: 35,
            paddingRight: 35,
            width: '100%',
            paddingBottom: 50,
          }}>
          {/* <View
            style={{
              alignItems: 'center',
              justifyContent: 'center',
              marginBottom: 22,
              width: 105,
              height: 105,
            }}>
            <Image
              source={require('../../assets/img/empty.png')}
              style={{
                width: 105,
                height: 105,
                borderRadius: 105,
                overflow: 'hidden',
              }}
              resizeMode={'cover'}
            />
          </View> */}
          <Text style={styles.modalName}>{userName}</Text>
          <View
            style={{
              display: 'flex',
              flexDirection: 'row',
              marginBottom: 30,
              alignItems: 'center',
            }}>
            <Text style={[styles.modalDate, {marginRight: 5}]}>
              Katılma Tarihi:
            </Text>
            <Text style={[styles.modalDate2, {marginRight: 30}]}>
              {userDate}
            </Text>
            <Text style={[styles.modalDate, {marginRight: 5}]}>
              Affiliate ID:
            </Text>
            <Text style={styles.modalDate2}>{userId}</Text>
          </View>

          <View
            style={{
              display: 'flex',
              flexDirection: 'row',
              flexWrap: 'wrap',
              justifyContent: 'space-between',
            }}>
            <TouchableOpacity
              style={[styles.inputStyle, styles.profileBtnStyle]}
              onPress={() => navigation.navigate('EditProfile')}>
              {/* <Profil width={16} height={19} style={{marginRight: 28}} /> */}
              <View style={styles.profileBtnImgStyle}>
                <Image
                  source={require('../../assets/img/login_img_w.png')}
                  style={{
                    width: 27,
                    height: 32,
                  }}
                />
              </View>
              <View
                style={{
                  display: 'flex',
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'flex-end',
                }}>
                <View>
                  <Text style={styles.profileBtn}>Profili</Text>
                  <Text style={styles.profileBtn}>Düzenle</Text>
                </View>
                <Image
                  source={require('../../assets/img/arrow_w.png')}
                  style={{
                    width: 4,
                    height: 8,
                  }}
                />
              </View>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.inputStyle, styles.profileBtnStyle]}
              onPress={() => navigation.navigate('EditNotifications')}>
              {/* <Bildirim width={16} height={19} style={{marginRight: 28}} /> */}
              <View style={styles.profileBtnImgStyle}>
                <Image
                  source={require('../../assets/img/bildirim_w.png')}
                  style={{
                    width: 27,
                    height: 32,
                  }}
                />
              </View>
              <View
                style={{
                  display: 'flex',
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'flex-end',
                }}>
                <View>
                  <Text style={styles.profileBtn}>Bildirim</Text>
                  <Text style={styles.profileBtn}>Ayarları</Text>
                </View>
                <Image
                  source={require('../../assets/img/arrow_w.png')}
                  style={{
                    width: 4,
                    height: 8,
                  }}
                />
              </View>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.inputStyle, styles.profileBtnStyle]}
              onPress={() => navigation.navigate('BankInfo')}>
              {/* <Banka width={20} height={14} style={{marginRight: 28}} /> */}
              <View style={styles.profileBtnImgStyle}>
                <Image
                  source={require('../../assets/img/bank-info_w.png')}
                  style={{
                    width: 27,
                    height: 19,
                    marginRight: 10,
                  }}
                />
              </View>
              <View
                style={{
                  display: 'flex',
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'flex-end',
                }}>
                <View>
                  <Text style={styles.profileBtn}>Banka</Text>
                  <Text style={styles.profileBtn}>Bilgileri</Text>
                </View>
                <Image
                  source={require('../../assets/img/arrow_w.png')}
                  style={{
                    width: 4,
                    height: 8,
                  }}
                />
              </View>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.inputStyle, styles.profileBtnStyle]}
              // onPress={() => navigation.navigate('Info')}>
              onPress={() => Linking.openURL('https://payfour.com/sss')}>
              {/* <Bilgi width={20} height={20} style={{marginRight: 28}} /> */}
              <View style={styles.profileBtnImgStyle}>
                <Image
                  source={require('../../assets/img/info_w.png')}
                  style={{
                    width: 32,
                    height: 32,
                  }}
                />
              </View>
              <View
                style={{
                  display: 'flex',
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'flex-end',
                }}>
                <View>
                  <Text style={styles.profileBtn}>Uygulama</Text>
                  <Text style={styles.profileBtn}>Hakkında</Text>
                </View>
                <Image
                  source={require('../../assets/img/arrow_w.png')}
                  style={{
                    width: 4,
                    height: 8,
                  }}
                />
              </View>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.inputStyle, styles.profileBtnStyle]}
              // onPress={() => navigation.navigate('Terms')}>
              onPress={() =>
                Linking.openURL('https://panel.gelirortaklari.com/terms')
              }>
              {/* <Sartlar width={14} height={18} style={{marginRight: 28}} /> */}
              <View style={styles.profileBtnImgStyle}>
                <Image
                  source={require('../../assets/img/docs_w.png')}
                  style={{
                    width: 24,
                    height: 32,
                  }}
                />
              </View>
              <View
                style={{
                  display: 'flex',
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'flex-end',
                }}>
                <View>
                  <Text style={styles.profileBtn}>Şartlar ve</Text>
                  <Text style={styles.profileBtn}>Koşullar</Text>
                </View>
                <Image
                  source={require('../../assets/img/arrow_w.png')}
                  style={{
                    width: 4,
                    height: 8,
                  }}
                />
              </View>
            </TouchableOpacity>
            {/* <TouchableOpacity
              style={[styles.inputStyle, styles.profileBtnStyle]}
              onPress={() => navigation.navigate('Contact')}>
              <View style={styles.profileBtnImgStyle}>
                <Image
                  source={require('../../assets/img/contact_w.png')}
                  style={{
                    width: 36,
                    height: 32,
                  }}
                />
              </View>
              <View
                style={{
                  display: 'flex',
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'flex-end',
                }}>
                <View>
                  <Text style={styles.profileBtn}>İletişim</Text>
                  <Text style={styles.profileBtn}>Bilgileri</Text>
                </View>
                <Image
                  source={require('../../assets/img/arrow_w.png')}
                  style={{
                    width: 4,
                    height: 8,
                  }}
                />
              </View>
            </TouchableOpacity> */}
            <TouchableOpacity
              style={[styles.inputStyle, styles.profileBtnStyle]}
              onPress={handleExit}>
              {/* <Cikis width={16} height={19} style={{marginRight: 28}} /> */}
              <View style={styles.profileBtnImgStyle}>
                <Image
                  source={require('../../assets/img/exit_w.png')}
                  style={{
                    width: 29,
                    height: 32,
                  }}
                />
              </View>
              <View
                style={{
                  display: 'flex',
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'flex-end',
                }}>
                <View>
                  <Text style={styles.profileBtn}>Çıkış</Text>
                  <Text style={styles.profileBtn}>Yap</Text>
                </View>
                <Image
                  source={require('../../assets/img/arrow_w.png')}
                  style={{
                    width: 4,
                    height: 8,
                  }}
                />
              </View>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};
const EditProfile = ({navigation}) => {
  const [loading, setLoading] = useState(false);
  const [userName, setUserName] = useState('');
  const [userSurname, setUserSurname] = useState('');
  const [userEmail, setUserEmail] = useState('');
  const [userPhone, setUserPhone] = useState('');

  const handleUpdate = () => {
    var obj = {};
    AsyncStorage.getItem('auth_token').then(token =>
      //navigation.replace(value === null ? 'Auth' : 'TabNavigationRoutes'),
      {
        obj.token = token;
        AsyncStorage.getItem('userId').then(id => {
          obj.id = id;
          updateProfile(obj);
        });
      },
    );
  };
  const updateProfile = async obj => {
    console.log(obj);
    console.log(userPhone);
    console.log(parseInt(userPhone, 10));
    let url =
      'https://gelirortaklari.api.hasoffers.com/Apiv3/json?api_key=' +
      obj.token +
      '&Target=Affiliate_AffiliateUser&Method=update&data[email]=' +
      userEmail +
      '&data[last_name]=' +
      userSurname +
      '&data[first_name]=' +
      userName +
      '&data[cell_phone]=' +
      userPhone +
      '&id=' +
      obj.id;
    console.log(url);
    const response = await fetch(
      'https://gelirortaklari.api.hasoffers.com/Apiv3/json?api_key=' +
        obj.token +
        '&Target=Affiliate_AffiliateUser&Method=update&data[email]=' +
        userEmail +
        '&data[last_name]=' +
        userSurname +
        '&data[first_name]=' +
        userName +
        '&data[cell_phone]=' +
        userPhone +
        '&id=' +
        obj.id,
    );
    const json = await response.json();
    console.log(json);
  };
  const getProfile = async obj => {
    console.log(obj);
    setLoading(true);
    const response = await fetch(
      'https://gelirortaklari.api.hasoffers.com/Apiv3/json?api_key=' +
        obj.token +
        '&Target=Affiliate_AffiliateUser&Method=findById&id=' +
        obj.id,
    );
    const json = await response.json();
    //console.log(json);
    console.log(json.response.data.AffiliateUser);
    setUserName(json.response.data.AffiliateUser.first_name);
    setUserSurname(json.response.data.AffiliateUser.last_name);
    setUserEmail(json.response.data.AffiliateUser.email);
    setUserPhone(json.response.data.AffiliateUser.cell_phone);
    setLoading(false);
  };
  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', () => {
      // do something
      console.log('Hello World!');
      var obj = {};
      AsyncStorage.getItem('auth_token').then(token =>
        //navigation.replace(value === null ? 'Auth' : 'TabNavigationRoutes'),
        {
          obj.token = token;
          AsyncStorage.getItem('userId').then(id => {
            obj.id = id;
            getProfile(obj);
          });
        },
      );
    });
    return unsubscribe;
  }, [navigation]);
  return (
    <SafeAreaView style={{flex: 1, backgroundColor: '#fff'}}>
      <Loader loading={loading} />
      {/* <View style={styles.topStyle}>
        <TouchableOpacity
          style={styles.buttonClose}
          onPress={() => navigation.navigate('Profile')}>
          <Image
            source={require('../../assets/img/back_btn.png')}
            style={{
              width: 13,
              height: 23,
            }}
          />
        </TouchableOpacity>
        <View style={{alignItems: 'center'}}>
          <Text style={styles.headerTextStyle}>Profili Düzenle</Text>
        </View>
        <View style={styles.notificationIcon}>
          <View style={styles.notificationImg}>
            <Image
              source={require('../../assets/img/bildirim.png')}
              style={{
                width: 18,
                height: 21,
              }}
            />
          </View>
          <View style={styles.notificationNumber}>
            <Text style={styles.notificationText}>1</Text>
          </View>
        </View>
      </View> */}
      <TabHeader routetarget="Profile" name="Profili Düzenle" count="0" />

      <ScrollView
        keyboardShouldPersistTaps="handled"
        style={[styles.scrollView, {width: '100%', paddingBottom: 100}]}>
        <View
          style={{
            flex: 1,
            flexDirection: 'column',
            alignItems: 'flex-start',
            justifyContent: 'flex-start',
            paddingTop: 27,
            paddingLeft: 35,
            paddingRight: 35,
            width: '100%',
          }}>
          <View
            style={{
              display: 'flex',
              flexDirection: 'row',
              justifyContent: 'space-between',
            }}>
            <View style={{width: '45%', marginRight: '10%'}}>
              <Text
                style={[
                  styles.inputTitleStyle,
                  {
                    fontSize: 14,
                    fontWeight: '700',
                    marginBottom: 14,
                    color: '#1D1D25',
                  },
                ]}>
                Ad
              </Text>
              <TextInput
                style={{
                  borderColor: '#EBEBEB',
                  borderWidth: 1,
                  padding: 20,
                  fontSize: 12,
                  borderRadius: 10,
                  height: 54,
                  color: '#1D1D25',
                  marginBottom: 18,
                }}
                onChangeText={UserName => setUserName(UserName)}
                autoCapitalize="none"
                placeholder={userName}
                value={userName}
                placeholderTextColor="#7E797F"
                returnKeyType="next"
                underlineColorAndroid="#f000"
                blurOnSubmit={false}
              />
            </View>
            <View style={{width: '45%'}}>
              <Text
                style={[
                  styles.inputTitleStyle,
                  {
                    fontSize: 14,
                    fontWeight: '700',
                    marginBottom: 14,
                    color: '#1D1D25',
                  },
                ]}>
                Soyad
              </Text>
              <TextInput
                style={{
                  borderColor: '#EBEBEB',
                  borderWidth: 1,
                  padding: 20,
                  fontSize: 12,
                  borderRadius: 10,
                  height: 54,
                  color: '#1D1D25',
                  marginBottom: 18,
                }}
                onChangeText={UserSurname => setUserSurname(UserSurname)}
                autoCapitalize="none"
                placeholder={userSurname}
                value={userSurname}
                placeholderTextColor="#7E797F"
                returnKeyType="next"
                underlineColorAndroid="#f000"
                blurOnSubmit={false}
              />
            </View>
          </View>
          <Text
            style={[
              styles.inputTitleStyle,
              {
                fontSize: 14,
                fontWeight: '700',
                marginBottom: 14,
                color: '#1D1D25',
              },
            ]}>
            E-posta Adresi
          </Text>
          <TextInput
            style={{
              borderColor: '#EBEBEB',
              borderWidth: 1,
              padding: 20,
              fontSize: 12,
              borderRadius: 10,
              height: 54,
              color: '#1D1D25',
              marginBottom: 18,
              width: '100%',
            }}
            onChangeText={UserEmail => setUserEmail(UserEmail)}
            autoCapitalize="none"
            placeholder={userEmail}
            value={userEmail}
            placeholderTextColor="#7E797F"
            keyboardType="email-address"
            returnKeyType="next"
            underlineColorAndroid="#f000"
            blurOnSubmit={false}
          />
          <Text
            style={[
              styles.inputTitleStyle,
              {
                fontSize: 14,
                fontWeight: '700',
                marginBottom: 14,
                color: '#1D1D25',
              },
            ]}>
            Telefon
          </Text>
          <TextInput
            style={{
              borderColor: '#EBEBEB',
              borderWidth: 1,
              padding: 20,
              fontSize: 12,
              borderRadius: 10,
              height: 54,
              color: '#1D1D25',
              marginBottom: 50,
              width: '100%',
            }}
            onChangeText={UserPhone => setUserPhone(UserPhone)}
            autoCapitalize="none"
            placeholder={userPhone}
            value={userPhone}
            placeholderTextColor="#7E797F"
            keyboardType="email-address"
            returnKeyType="next"
            underlineColorAndroid="#f000"
            blurOnSubmit={false}
          />
          <TouchableOpacity
            style={styles.buttonStyle}
            activeOpacity={0.5}
            onPress={handleUpdate}>
            <Text style={styles.buttonTextStyle}>GÜNCELLE</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};
const EditNotifications = ({navigation}) => {
  const [loading, setLoading] = useState(false);
  const [userNotifications, setUserNotifications] = useState('');
  const [selected, setSelected] = React.useState('');

  const [promo, setPromo] = React.useState(true);
  const [popularProduct, setPopularProduct] = React.useState(true);
  const [coupon, setCoupon] = React.useState(true);
  const [newOffer, setNewOffer] = React.useState(true);
  const [termUpdate, setTermUpdate] = React.useState(true);
  const [earnings, setEarnings] = React.useState(true);
  const handleUpdate = () => {
    var obj = {};
    AsyncStorage.getItem('auth_token').then(token =>
      //navigation.replace(value === null ? 'Auth' : 'TabNavigationRoutes'),
      {
        obj.token = token;
        AsyncStorage.getItem('userId').then(id => {
          obj.id = id;
          updateProfile(obj);
        });
      },
    );
  };
  const updateProfile = async obj => {
    const response = await fetch(
      'https://gelirortaklari.api.hasoffers.com/Apiv3/json?api_key=' +
        obj.token +
        '&Target=Affiliate_AffiliateUser&Method=update&id=' +
        obj.id +
        '&data[wants_alerts]=' +
        userNotifications,
    );
    const json = await response.json();
    console.log(json);
  };
  const getProfile = async obj => {
    console.log(obj);
    setLoading(true);
    const response = await fetch(
      'https://gelirortaklari.api.hasoffers.com/Apiv3/json?api_key=' +
        obj.token +
        '&Target=Affiliate_AffiliateUser&Method=findById&id=' +
        obj.id,
    );
    const json = await response.json();
    //console.log(json);
    console.log(json.response.data.AffiliateUser);
    setUserNotifications(json.response.data.AffiliateUser.wants_alerts);
    setSelected(json.response.data.AffiliateUser.wants_alerts);
    setLoading(false);
  };
  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', () => {
      // do something
      console.log('Hello World!');
      var obj = {};
      AsyncStorage.getItem('auth_token').then(token =>
        //navigation.replace(value === null ? 'Auth' : 'TabNavigationRoutes'),
        {
          obj.token = token;
          AsyncStorage.getItem('userId').then(id => {
            obj.id = id;
            getProfile(obj);
          });
        },
      );
    });
    return unsubscribe;
  }, [navigation]);
  return (
    <SafeAreaView style={{flex: 1, backgroundColor: '#fff'}}>
      <Loader loading={loading} />
      {/* <View style={styles.topStyle}>
        <TouchableOpacity
          style={styles.buttonClose}
          onPress={() => navigation.navigate('Profile')}>
          <Image
            source={require('../../assets/img/back_btn.png')}
            style={{
              width: 13,
              height: 23,
            }}
          />
        </TouchableOpacity>
        <View style={{alignItems: 'center'}}>
          <Text style={styles.headerTextStyle}>Bildirimleri Düzenle</Text>
        </View>
        <View style={styles.notificationIcon}>
          <View style={styles.notificationImg}>
            <Image
              source={require('../../assets/img/bildirim.png')}
              style={{
                width: 18,
                height: 21,
              }}
            />
          </View>
          <View style={styles.notificationNumber}>
            <Text style={styles.notificationText}>1</Text>
          </View>
        </View>
      </View> */}
      <TabHeader routetarget="Profile" name="Bildirimleri Düzenle" count="0" />

      <ScrollView keyboardShouldPersistTaps="handled" style={styles.scrollView}>
        <View
          style={{
            flex: 1,
            flexDirection: 'column',
            alignItems: 'flex-start',
            justifyContent: 'flex-start',
            paddingTop: 56,
            paddingLeft: 35,
            paddingRight: 35,
            width: '100%',
          }}>
          <View
            style={{
              display: 'flex',
              flexDirection: 'row',
              alignItems: 'center',
              paddingBottom: 14,
              // borderBottomWidth: 1,
              // borderBottomColor: '#ebebeb',
              marginBottom: 21,
            }}>
            <View style={{width: '74%', marginRight: '13%'}}>
              {/* <Text
                style={{
                  fontSize: 14,
                  fontWeight: '700',
                  marginBottom: 8,
                  color: '#1D1D25',
                }}>
                Öne Çıkan Kampanya
              </Text>
              <Text style={{fontSize: 10, color: '#7E797F'}}>
                Kupon kodu, özel indirimler, bonus kurgusu ve benzeri yeni bir
                marka promosyonu eklendiğinde bildirim gönder
              </Text> */}
              <Text
                style={{
                  fontSize: 14,
                  fontWeight: '700',
                  marginBottom: 8,
                  color: '#1D1D25',
                }}>
                Tüm Bildirimler
              </Text>
              <Text style={{fontSize: 10, color: '#7E797F'}}>
                Uygulamanın bildirim göndermesine izin ver
              </Text>
            </View>
            <View style={{width: '13%'}}>
              <TouchableOpacity
                style={{width: '100%'}}
                onPress={() => setPromo(!promo)}>
                <View
                  style={{
                    width: '100%',
                    height: 26,
                    borderRadius: 30,
                    backgroundColor: promo ? '#1D1D25' : '#C9C9C9',
                  }}>
                  <View
                    style={{
                      width: 20,
                      height: 20,
                      borderRadius: 20,
                      backgroundColor: '#fff',
                      position: 'absolute',
                      top: 3,
                      left: promo ? 'initial' : 4,
                      right: promo ? 4 : 'initial',
                    }}></View>
                </View>
              </TouchableOpacity>
            </View>
          </View>
          {/* <View
            style={{
              display: 'flex',
              flexDirection: 'row',
              alignItems: 'center',
              paddingBottom: 14,
              borderBottomWidth: 1,
              borderBottomColor: '#ebebeb',
              marginBottom: 21,
            }}>
            <View style={{width: '74%', marginRight: '13%'}}>
              <Text
                style={{
                  fontSize: 14,
                  fontWeight: '700',
                  marginBottom: 8,
                  color: '#1D1D25',
                }}>
                Popüler Ürün
              </Text>
              <Text style={{fontSize: 10, color: '#7E797F'}}>
                Yeni popüler bir ürün eklediğinde bildirim gönder
              </Text>
            </View>
            <View style={{width: '13%'}}>
              <TouchableOpacity
                style={{width: '100%'}}
                onPress={() => setPopularProduct(!popularProduct)}>
                <View
                  style={{
                    width: '100%',
                    height: 26,
                    borderRadius: 30,
                    backgroundColor: popularProduct ? '#1D1D25' : '#C9C9C9',
                  }}>
                  <View
                    style={{
                      width: 20,
                      height: 20,
                      borderRadius: 20,
                      backgroundColor: '#fff',
                      position: 'absolute',
                      top: 3,
                      left: popularProduct ? 'initial' : 4,
                      right: popularProduct ? 4 : 'initial',
                    }}></View>
                </View>
              </TouchableOpacity>
            </View>
          </View>
          <View
            style={{
              display: 'flex',
              flexDirection: 'row',
              alignItems: 'center',
              paddingBottom: 14,
              borderBottomWidth: 1,
              borderBottomColor: '#ebebeb',
              marginBottom: 21,
            }}>
            <View style={{width: '74%', marginRight: '13%'}}>
              <Text
                style={{
                  fontSize: 14,
                  fontWeight: '700',
                  marginBottom: 8,
                  color: '#1D1D25',
                }}>
                Kupon Kodu
              </Text>
              <Text style={{fontSize: 10, color: '#7E797F'}}>
                İndirim sağlayan kupon kodları eklendiğinde bildirim gönder
              </Text>
            </View>
            <View style={{width: '13%'}}>
              <TouchableOpacity
                style={{width: '100%'}}
                onPress={() => setCoupon(!coupon)}>
                <View
                  style={{
                    width: '100%',
                    height: 26,
                    borderRadius: 30,
                    backgroundColor: coupon ? '#1D1D25' : '#C9C9C9',
                  }}>
                  <View
                    style={{
                      width: 20,
                      height: 20,
                      borderRadius: 20,
                      backgroundColor: '#fff',
                      position: 'absolute',
                      top: 3,
                      left: coupon ? 'initial' : 4,
                      right: coupon ? 4 : 'initial',
                    }}></View>
                </View>
              </TouchableOpacity>
            </View>
          </View>
          <View
            style={{
              display: 'flex',
              flexDirection: 'row',
              alignItems: 'center',
              paddingBottom: 14,
              borderBottomWidth: 1,
              borderBottomColor: '#ebebeb',
              marginBottom: 21,
            }}>
            <View style={{width: '74%', marginRight: '13%'}}>
              <Text
                style={{
                  fontSize: 14,
                  fontWeight: '700',
                  marginBottom: 8,
                  color: '#1D1D25',
                }}>
                Yeni Teklif Açılması
              </Text>
              <Text style={{fontSize: 10, color: '#7E797F'}}>
                Teklif menüsüne yeni bir affiliate program eklendiğinde bildirim
                gönder
              </Text>
            </View>
            <View style={{width: '13%'}}>
              <TouchableOpacity
                style={{width: '100%'}}
                onPress={() => setNewOffer(!newOffer)}>
                <View
                  style={{
                    width: '100%',
                    height: 26,
                    borderRadius: 30,
                    backgroundColor: newOffer ? '#1D1D25' : '#C9C9C9',
                  }}>
                  <View
                    style={{
                      width: 20,
                      height: 20,
                      borderRadius: 20,
                      backgroundColor: '#fff',
                      position: 'absolute',
                      top: 3,
                      left: newOffer ? 'initial' : 4,
                      right: newOffer ? 4 : 'initial',
                    }}></View>
                </View>
              </TouchableOpacity>
            </View>
          </View>
          <View
            style={{
              display: 'flex',
              flexDirection: 'row',
              alignItems: 'center',
              paddingBottom: 14,
              borderBottomWidth: 1,
              borderBottomColor: '#ebebeb',
              marginBottom: 21,
            }}>
            <View style={{width: '74%', marginRight: '13%'}}>
              <Text
                style={{
                  fontSize: 14,
                  fontWeight: '700',
                  marginBottom: 8,
                  color: '#1D1D25',
                }}>
                Teklif Koşul Değişikliği
              </Text>
              <Text style={{fontSize: 10, color: '#7E797F'}}>
                Markaların affiliate programlarının koşulları değiştiğinde veya
                program durduğunda bildirim gönder
              </Text>
            </View>
            <View style={{width: '13%'}}>
              <TouchableOpacity
                style={{width: '100%'}}
                onPress={() => setTermUpdate(!termUpdate)}>
                <View
                  style={{
                    width: '100%',
                    height: 26,
                    borderRadius: 30,
                    backgroundColor: termUpdate ? '#1D1D25' : '#C9C9C9',
                  }}>
                  <View
                    style={{
                      width: 20,
                      height: 20,
                      borderRadius: 20,
                      backgroundColor: '#fff',
                      position: 'absolute',
                      top: 3,
                      left: termUpdate ? 'initial' : 4,
                      right: termUpdate ? 4 : 'initial',
                    }}></View>
                </View>
              </TouchableOpacity>
            </View>
          </View>
          <View
            style={{
              display: 'flex',
              flexDirection: 'row',
              alignItems: 'center',
              paddingBottom: 14,
              borderBottomWidth: 1,
              borderBottomColor: '#ebebeb',
              marginBottom: 21,
            }}>
            <View style={{width: '74%', marginRight: '13%'}}>
              <Text
                style={{
                  fontSize: 14,
                  fontWeight: '700',
                  marginBottom: 8,
                  color: '#1D1D25',
                }}>
                Hakediş
              </Text>
              <Text style={{fontSize: 10, color: '#7E797F'}}>
                Onaylanan bakiye netleştiğinde bildirim gönder
              </Text>
            </View>
            <View style={{width: '13%'}}>
              <TouchableOpacity
                style={{width: '100%'}}
                onPress={() => setEarnings(!earnings)}>
                <View
                  style={{
                    width: '100%',
                    height: 26,
                    borderRadius: 30,
                    backgroundColor: earnings ? '#1D1D25' : '#C9C9C9',
                  }}>
                  <View
                    style={{
                      width: 20,
                      height: 20,
                      borderRadius: 20,
                      backgroundColor: '#fff',
                      position: 'absolute',
                      top: 3,
                      left: earnings ? 'initial' : 4,
                      right: earnings ? 4 : 'initial',
                    }}></View>
                </View>
              </TouchableOpacity>
            </View>
          </View> */}
          {/* <TouchableOpacity
            style={styles.buttonStyle}
            activeOpacity={0.5}
            onPress={handleUpdate}>
            <Text style={styles.buttonTextStyle}>GÜNCELLE</Text>
          </TouchableOpacity> */}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};
const BankInfo = ({navigation}) => {
  const [loading, setLoading] = useState(false);

  const sendMail = () => {
    console.log('sendMail');
    Linking.openURL('mailto:go@publicisgroupe.com');
  };
  return (
    <SafeAreaView style={{flex: 1, backgroundColor: '#fff'}}>
      <Loader loading={loading} />
      {/* <View style={styles.topStyle}>
        <TouchableOpacity
          style={styles.buttonClose}
          onPress={() => navigation.navigate('Profile')}>
          <Image
            source={require('../../assets/img/back_btn.png')}
            style={{
              width: 13,
              height: 23,
            }}
          />
        </TouchableOpacity>
        <View style={{alignItems: 'center'}}>
          <Text style={styles.headerTextStyle}>Banka Bilgilerim</Text>
        </View>
        <View style={styles.notificationIcon}>
          <View style={styles.notificationImg}>
            <Image
              source={require('../../assets/img/bildirim.png')}
              style={{
                width: 18,
                height: 21,
              }}
            />
          </View>
          <View style={styles.notificationNumber}>
            <Text style={styles.notificationText}>1</Text>
          </View>
        </View>
      </View> */}
      <TabHeader routetarget="Profile" name="Banka Bilgilerim" count="0" />

      <View
        style={[
          styles.centeredView,
          {
            backgroundColor: '#fff',
            textAlign: 'center',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            paddingLeft: 30,
            paddingRight: 30,
            flex: 1,
          },
        ]}>
        <Bilgi width={33} height={33} style={{marginBottom: 40}} />
        {/* <Image
          source={require('../../assets/img/info.png')}
          style={{
            width: 33,
            height: 33,
            marginBottom: 40,
          }}
        /> */}
        <Text style={styles.modalTitle}>Önemli Bilgilendirme</Text>
        <Text style={styles.modalDesc}>
          Banka bilgilerinizi güncellemek için, güncel banka hesap bilgilerinizi
          (bankanızdan temin edeceğiniz resmi bir belge ile)
          go@publicisgroupe.com e-posta adresine göndermenizi rica ederiz.
        </Text>
        <TouchableOpacity
          style={styles.buttonStyle}
          activeOpacity={0.5}
          onPress={sendMail}>
          <Text style={styles.buttonTextStyle}>E-POSTA GÖNDER</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};
const Contact = ({navigation}) => {
  const [loading, setLoading] = useState(false);

  const sendMail = () => {
    console.log('sendMail');
    Linking.openURL('mailto:go@publicisgroupe.com');
  };
  const sendMsg = () => {
    console.log('sendMsg');
    Linking.openURL('https://wa.me/905425763055');
  };
  return (
    <SafeAreaView style={{flex: 1, backgroundColor: '#fff'}}>
      <Loader loading={loading} />
      {/* <View style={styles.topStyle}>
        <TouchableOpacity
          style={styles.buttonClose}
          onPress={() => navigation.navigate('Profile')}>
          <Image
            source={require('../../assets/img/back_btn.png')}
            style={{
              width: 13,
              height: 23,
            }}
          />
        </TouchableOpacity>
        <View style={{alignItems: 'center'}}>
          <Text style={styles.headerTextStyle}>İletişim</Text>
        </View>
        <View style={styles.notificationIcon}>
          <View style={styles.notificationImg}>
            <Image
              source={require('../../assets/img/bildirim.png')}
              style={{
                width: 18,
                height: 21,
              }}
            />
          </View>
          <View style={styles.notificationNumber}>
            <Text style={styles.notificationText}>1</Text>
          </View>
        </View>
      </View> */}
      <TabHeader routetarget="Profile" name="İletişim" count="0" />

      <View
        style={[
          styles.centeredView,
          {
            backgroundColor: '#fff',
            textAlign: 'center',
            display: 'flex',
            flexDirection: 'column',
            paddingLeft: 30,
            paddingRight: 30,
            paddingTop: 58,
            paddingBottom: 58,
            flex: 1,
          },
        ]}>
        <View>
          <View
            style={{
              display: 'flex',
              flexDirection: 'row',
              alignItems: 'center',
              marginBottom: 28,
            }}>
            <Email width={42} height={42} style={{marginRight: 14}} />
            {/* <Image
              source={require('../../assets/img/email.png')}
              style={{
                width: 42,
                height: 42,
                marginRight: 14,
              }}
            /> */}
            <Text style={{fontSize: 24, fontWeight: '700', color: '#1D1D25'}}>
              E-Posta
            </Text>
          </View>
          <View style={{marginBottom: 30}}>
            <Text style={{fontSize: 14, color: '#1D1D25'}}>
              Finansal, teknolojik ve operasyonel kapsamda Tüm sorularınızı bize
              e-posta üzerinden sorabilirsiniz.
            </Text>
          </View>
          <TouchableOpacity
            style={[
              styles.buttonStyle,
              {
                fontSize: 12,
                width: 184,
                height: 39,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              },
            ]}
            activeOpacity={0.5}
            onPress={sendMail}>
            <Text style={{fontSize: 12, fontWeight: '700', color: '#ffffff'}}>
              E-POSTA GÖNDER
            </Text>
          </TouchableOpacity>
        </View>
        {/* <View
          style={{
            width: '100%',
            height: 1,
            backgroundColor: '#1D1D25',
            marginTop: 50,
            marginBottom: 50,
            opacity: 0.1,
          }}></View> */}
        {/* <View>
          <View
            style={{
              display: 'flex',
              flexDirection: 'row',
              alignItems: 'center',
              marginBottom: 28,
            }}>
            <Whatsapp width={42} height={42} style={{marginRight: 14}} />

            
            <Text style={{fontSize: 24, fontWeight: '700', color: '#1D1D25'}}>
              WhatsApp
            </Text>
          </View>
          <View style={{marginBottom: 30}}>
            <Text style={{fontSize: 14, color: '#1D1D25'}}>
              İhtiyacınız olan herhangi bir konuda WhatsApp Business kanalımız
              üzerinden de bize ulaşabilirsiniz.
            </Text>
          </View>
          <TouchableOpacity
            style={[
              styles.buttonStyle,
              {
                fontSize: 12,
                width: 184,
                height: 39,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              },
            ]}
            activeOpacity={0.5}
            onPress={sendMsg}>
            <Text style={{fontSize: 12, fontWeight: '700', color: '#ffffff'}}>
              MESAJ GÖNDER
            </Text>
          </TouchableOpacity>
        </View> */}
      </View>
    </SafeAreaView>
  );
};
const Info = ({navigation}) => {
  const [loading, setLoading] = useState(false);

  return (
    <SafeAreaView style={{flex: 1, backgroundColor: '#fff'}}>
      <Loader loading={loading} />
      {/* <View style={styles.topStyle}>
        <TouchableOpacity
          style={styles.buttonClose}
          onPress={() => navigation.navigate('Profile')}>
          <Image
            source={require('../../assets/img/back_btn.png')}
            style={{
              width: 13,
              height: 23,
            }}
          />
        </TouchableOpacity>
        <View style={{alignItems: 'center'}}>
          <Text style={styles.headerTextStyle}>Uygulama Hakkında</Text>
        </View>
        <View style={styles.notificationIcon}>
          <View style={styles.notificationImg}>
            <Image
              source={require('../../assets/img/bildirim.png')}
              style={{
                width: 18,
                height: 21,
              }}
            />
          </View>
          <View style={styles.notificationNumber}>
            <Text style={styles.notificationText}>1</Text>
          </View>
        </View>
      </View> */}
      <TabHeader routetarget="Profile" name="Uygulama Hakkında" count="0" />

      <View
        style={[
          styles.centeredView,
          {
            backgroundColor: '#fff',
            textAlign: 'center',
            display: 'flex',
            flexDirection: 'column',
            paddingLeft: 30,
            paddingRight: 30,
            paddingTop: 40,
            paddingBottom: 40,
            flex: 1,
          },
        ]}>
        <Text
          style={{
            fontSize: 24,
            fontWeight: '700',
            color: '#1D1D25',
            marginBottom: 30,
          }}>
          Payfour
        </Text>
        <Text
          style={{
            fontSize: 14,
            color: '#1D1D25',
            marginBottom: 20,
            lineHeight: 25,
          }}>
          There are many variations of passages of Lorem Ipsum available, but
          the majority have suffered alteration in some form, by injected
          humour, or randomised words which don’t look even slightly believable.
          If you are going to use a passage of Lorem Ipsum, you need to be sure
          there isn’t anything embarrassing hidden in the middle of text.
        </Text>
        <Text style={{fontSize: 14, color: '#1D1D25', lineHeight: 25}}>
          All the Lorem Ipsum generators on the Internet tend to repeat
          predefined chunks as necessary, making this the first true generator
          on the Internet. It uses a dictionary of over 200 Latin words,
          combined with a handful of model sentence structures, to generate
          Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is
          therefore always free from repetition, injected humour, or
          non-characteristic words etc.
        </Text>
      </View>
    </SafeAreaView>
  );
};
const Terms = ({navigation}) => {
  const [loading, setLoading] = useState(false);

  return (
    <SafeAreaView style={{flex: 1, backgroundColor: '#fff'}}>
      <Loader loading={loading} />
      {/* <View style={styles.topStyle}>
        <TouchableOpacity
          style={styles.buttonClose}
          onPress={() => navigation.navigate('Profile')}>
          <Image
            source={require('../../assets/img/back_btn.png')}
            style={{
              width: 13,
              height: 23,
            }}
          />
        </TouchableOpacity>
        <View style={{alignItems: 'center'}}>
          <Text style={styles.headerTextStyle}>Şartlar ve Koşullar</Text>
        </View>
        <View style={styles.notificationIcon}>
          <View style={styles.notificationImg}>
            <Image
              source={require('../../assets/img/bildirim.png')}
              style={{
                width: 18,
                height: 21,
              }}
            />
          </View>
          <View style={styles.notificationNumber}>
            <Text style={styles.notificationText}>1</Text>
          </View>
        </View>
      </View> */}
      <TabHeader routetarget="Profile" name="Şartlar ve Koşullar" count="0" />

      <ScrollView
        keyboardShouldPersistTaps="handled"
        style={[styles.scrollView, {width: '100%'}]}>
        <View
          style={[
            styles.centeredView,
            {
              backgroundColor: '#fff',
              textAlign: 'center',
              display: 'flex',
              flexDirection: 'column',
              paddingLeft: 30,
              paddingRight: 30,
              paddingTop: 40,
              paddingBottom: 40,
              flex: 1,
            },
          ]}>
          <Text
            style={{
              fontSize: 14,
              color: '#1D1D25',
              marginBottom: 20,
              lineHeight: 25,
            }}>
            There are many variations of passages of Lorem Ipsum available, but
            the majority have suffered alteration in some form, by injected
            humour, or randomised words which don’t look even slightly
            believable. If you are going to use a passage of Lorem Ipsum, you
            need to be sure there isn’t anything embarrassing hidden in the
            middle of text.
          </Text>
          <Text style={{fontSize: 14, color: '#1D1D25', lineHeight: 25}}>
            All the Lorem Ipsum generators on the Internet tend to repeat
            predefined chunks as necessary, making this the first true generator
            on the Internet. It uses a dictionary of over 200 Latin words,
            combined with a handful of model sentence structures, to generate
            Lorem Ipsum which looks reasonable.
          </Text>
          <Text style={{fontSize: 14, color: '#1D1D25', lineHeight: 25}}>
            The generated Lorem Ipsum is therefore always free from repetition,
            injected humour, or non-characteristic words etc.
          </Text>
          <Text style={{fontSize: 14, color: '#1D1D25', lineHeight: 25}}>
            Contrary to popular belief, Lorem Ipsum is not simply random text.
            It has roots in a piece of classical Latin literature from 45 BC,
            making it over 2000 years old. Richard McClintock, a Latin professor
            at Hampden-Sydney College in Virginia, looked up one of the more
            obscure Latin words, consectetur, from a Lorem Ipsum passage, and
            going through the cites of the word in classical literature,
            discovered the undoubtable source.
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};
const ProfileScreen = () => {
  return (
    <Stack.Navigator initialRouteName="Profile">
      <Stack.Screen
        name="Profile"
        component={Profile}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="EditProfile"
        component={EditProfile}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="EditNotifications"
        component={EditNotifications}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="BankInfo"
        component={BankInfo}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="Info"
        component={Info}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="Terms"
        component={Terms}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="Contact"
        component={Contact}
        options={{headerShown: false}}
      />
    </Stack.Navigator>
  );
};
export default ProfileScreen;
