/* eslint-disable react-native/no-inline-styles */
// Example of Splash, Login and Sign Up in React Native
// https://aboutreact.com/react-native-login-and-signup/

// Import React and Component
import React, {useEffect, useState, useRef} from 'react';
import {
  View,
  Text,
  SafeAreaView, 
  FlatList,
  Dimensions,
  Image,
  Modal,
  StyleSheet,
  Alert,
  TouchableOpacity
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
// import {SelectList} from 'react-native-dropdown-select-list';
import {Dropdown} from 'react-native-element-dropdown';

import {createStackNavigator} from '@react-navigation/stack';
import {styles} from '../Components/Styles.js';
import Loader from '../Components/Loader';
import SubtabHeader from '../Components/SubtabHeader';
import {ScrollView} from 'react-native-gesture-handler';
import LinearGradient from 'react-native-linear-gradient';
import axios from 'react-native-axios';
import Clipboard from '@react-native-clipboard/clipboard';
// import Carousel from 'react-native-snap-carousel';
// import {WebView} from 'react-native-webview';
// import Pagination from "react-native-custom-pagination";
const Stack = createStackNavigator();
const Balance = ({navigation}) => {
  const [token, setToken] = React.useState('');
  //const [filterType, setFilterType] = React.useState('all');
  const [selected, setSelected] = React.useState({"key": "today", "value": "Bugün"});
  const [loading, setLoading] = useState(false);
  const [activeIndex, setActiveIndex] = useState(0);
  // const [successModalVisible, setSuccessModalVisible] = useState(true);
  const [modalVisible, setModalVisible] = useState(false);
  const [filterModalVisible, setFilterModalVisible] = useState(false);
  

  const width = Dimensions.get('window').width;
  const carouselRef = React.useRef(null);
  const [noData, setNoData] = useState(false);
  const [newData, setNewData] = useState(true);
  const scrollRef = useRef();
  const ddRef = useRef();
  const [walletData, setWalletData] = React.useState([
    {
      id: 0,
      brand: '...',
      click: '0',
      pay: '0 TL',
    },
  ]);

  const [transactionType, setTransactionType] = React.useState('all');
  const [filterType, setFilterType] = React.useState('week');
  const [filterName, setFilterName] = React.useState('Son 7 Gün');
  const [tempType, setTempType] = React.useState('all');

  const filterData = [
    {
      key: 'today',
      value: 'Bugün',
    },
    {
      key: 'yesterday',
      value: 'Dün',
    },
    {
      key: 'week',
      value: 'Son 7 Gün',
    },
    {
      key: 'twoweeks',
      value: 'Son 15 Gün',
    },    
    {
      key: 'thism',
      value: 'Bu Ay',
    },
  ];
  //const [setPage, setSetPage] = useState(1);
  const [activePage, setActivePage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);


  const [ibanModalVisible, setIbanModalVisible] = useState(false);
  const [iban, setIban] = useState('');

  const setPage = () => {
    console.log('setPage '+(activePage+1));
    console.log('setPage '+selected);
    console.log('newData '+newData);
    if(!newData){
    if((activePage+1)<=totalPages){
      setActivePage((activePage+1));

    let sel = selected;
    console.log("selected : ");
    console.log(sel);
    getPaymentData(selected, token, (activePage+1));
    }
  }
    
  }
  const _renderItem = ({item, index}) => {
    return (
      <TouchableOpacity
        onPress={() => {
          setNewData(true);
          setActiveIndex(index);
          getPaymentData(index);
        }}>
        <View
          style={{
            backgroundColor: '#e8e8e8',
            borderRadius: 30,
            height: 30,
            paddingTop: 5,
            paddingBottom: 5,
            paddingLeft: 20,
            paddingRight: 20,
            marginLeft: 0,
            marginRight: 10,
            marginBottom: 30,
            borderWidth: 1,
            borderColor: activeIndex === index ? '#1d1d25' : '#e8e8e8',
          }}>
          <Text
            style={{
              fontSize: 12,
              fontWeight: '700',
              color: '#1d1d25',
              textAlign: 'center',
            }}>
            {item.value}
          </Text>
        </View>
      </TouchableOpacity>
    );
  };
  const setFilterData = (type, cancels) =>{
    console.log(filterType);
    setFilterType(type);
    getPaymentData(type, cancels);
    setFilterModalVisible(false);
  }
  const getPaymentData = async (range, cancels, user, pg) => {
    console.log('getPaymentData');
    console.log(range);
    console.log('selected');
    console.log(selected);
    setLoading(true);
    let date = new Date();
    let endDate =
      date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate();
    console.log('endDate');
    console.log(endDate);

    let startDate = '';
    let mult = 0;
    //let rtext = 'Bugün';
    let qpath = '';
    let calcDate;
    switch (range) {
      case 'today':
        setFilterName('Bugün');
        startDate = endDate;        
        break;
      case 'yesterday':
        setFilterName('Dün');
        calcDate = new Date(Date.now() - 1 * 24 * 60 * 60 * 1000);
        startDate =
          calcDate.getFullYear() +
          '-' +
          (calcDate.getMonth() + 1) +
          '-' +
          calcDate.getDate();
          endDate = startDate;        
        break;
      case 'week':
        setFilterName('Son 7 Gün');
        calcDate = new Date(Date.now() - 6 * 24 * 60 * 60 * 1000);
        startDate =
          calcDate.getFullYear() +
          '-' +
          (calcDate.getMonth() + 1) +
          '-' +
          calcDate.getDate();        
        break;
      case 'twoweeks':
        setFilterName('Son 15 Gün');
          calcDate = new Date(Date.now() - 14 * 24 * 60 * 60 * 1000);
          startDate =
            calcDate.getFullYear() +
            '-' +
            (calcDate.getMonth() + 1) +
            '-' +
            calcDate.getDate();        
          break;
      case 'month':
        setFilterName('Son 30 Gün');
        calcDate = new Date(Date.now() - 29 * 24 * 60 * 60 * 1000);
        startDate =
          calcDate.getFullYear() +
          '-' +
          (calcDate.getMonth() + 1) +
          '-' +
          calcDate.getDate();        
        break;
      case 'thism':
        setFilterName('Bu Ay');
        startDate = date.getFullYear() + '-' + (date.getMonth() + 1) + '-01';        
        break;
    }

    
    console.log('path');
    qpath = 'http://payfourapp.test.kodegon.com/api/account/gettransactions?startDate='+startDate+'&endDate='+endDate+'&page=0&size=12';
    console.log(qpath);

    AsyncStorage.getItem('token').then(value =>{
      const config = {
        headers: { Authorization: `Bearer ${value}` }
      };

      axios.get(qpath, config).then(response => {
        console.log(response.data);
        console.log(response.data.data.items);
        formatData(response.data.data.items, cancels);        
        setLoading(false);
        getIban();
      })
      .catch(error => {
        setLoading(false);
        console.error("Error sending data: ", error);
        let msg="";
        (error.response.data.errors.message) ? msg += error.response.data.errors.message+"\n" : msg += "Ödeme hatası \n"; (error.response.data.errors.paymentError) ? msg += error.response.data.errors.paymentError+"\n" : msg += ""; Alert.alert(msg);
      });

    });
    
  };
  const getPendings = () =>{
    AsyncStorage.getItem('token').then(value =>{
      const config = {
        headers: { Authorization: `Bearer ${value}` }
      };

      axios.get('http://payfourapp.test.kodegon.com/api/account/getpendingorders?page=0&pageSize=12', config).then(response => {
        console.log(response.data);
        console.log(response.data.data.items);
        formatData(response.data.data.items);        
        setLoading(false);
        //getIban();
      })
      .catch(error => {
        setLoading(false);
        console.error("Error sending data: ", error);
        let msg="";
        (error.response.data.errors.message) ? msg += error.response.data.errors.message+"\n" : msg += "Ödeme hatası \n"; (error.response.data.errors.paymentError) ? msg += error.response.data.errors.paymentError+"\n" : msg += ""; Alert.alert(msg);
      });

    });
  }
  
  const formatData = (data, cancels) =>{
    console.log("format data");
    console.log(cancels);
    /*{
        "refNumber": 85000000022114,
        "dateTime": "2024-08-27T23:44:52.027",
        "amount": 100,
        "balance": 2369,
        "txnTypeId": 512,
        "txnName": "PaymentCash",
        "txnCategoryId": 1,
        "txnCategoryName": "Alışveriş"
      }*/
     let tmArr =[];
     for(var i=0;i < data.length;i++){
        let d = new Date(data[i].dateTime);
        let ds = checkZero(d.getDate())+'.'+checkZero((d.getMonth()+1))+'.'+d.getFullYear()+" / "+checkZero(d.getHours())+":"+checkZero(d.getMinutes());
        console.log(ds);
        //let as = checkCurrency(data[i].amount);
        let tmObj = {
          amount: checkCurrency(data[i].amount),
          date: ds,
          name: data[i].txnName,
          refno: data[i].refNumber,
          category:  data[i].txnCategoryId
        }
        if(cancels){
          if(data[i].txnCategoryId == 8) tmArr.push(tmObj);
       }else tmArr.push(tmObj);
     }
     console.log("arr");
     console.log(tmArr);
     setWalletData(tmArr);
  }
  const checkCurrency = data =>{
    if(parseInt(data) < 1000){
      return data+"TL"
    }else{
      let t = Math.floor(parseInt(data) / 1000);
      let o = parseInt(data) - (t*1000);
      let b;
      if(o < 1){
        b = "000";
      }else if(o < 10){
        b = "00"+o
      }else if(o < 100){
        b="0"+o;
      }else b = o
      let f = t+"."+b+"TL"
      console.log(f)
      return f;
    }
  }
  const checkZero = data =>{
    if(parseInt(data) < 10){
      return "0"+parseInt(data);
    }else return data;
  }
  const formatPayment = payment =>{
    let ta = String(payment).split('.');
          let tb = Math.floor(parseInt(ta[0])/1000);
          //console.log("tb : "+tb);
          let tc = parseInt(ta[0]) - (tb*1000);
          if(ta[0] > 999){
            if(tc < 10){
              tc = "00"+tc;
            } else if(tc < 100){
              tc = "0"+tc;
            }
          }
          let xtr = "00";
          if(ta[1] != null && ta[1] != undefined){
            
            if(ta[1].length < 2)ta[1] = ta[1]+"0";
            xtr = ta[1];
          }
          //console.log("tc : "+tc);
          if(tb > 999){
            let mil=Math.floor(parseInt(tb)/1000);
            let tho = parseInt(tb) - (mil*1000);
            tb = mil + "."+tho;
          }
          let td = tb > 0 ? tb + "." : "";
          let total = td+tc+","+xtr+" TL";
          return total;
  };
  const tokenize = user => {
    setToken(user);
  };

  const getIban = () =>{
    AsyncStorage.getItem('token').then(value =>{
      const config = {
        headers: { Authorization: `Bearer ${value}` }
      };
      console.log(value);
    axios.get('http://payfourapp.test.kodegon.com/api/account/getuser', config)
      .then(response => {
        console.log(response);
        console.log(response.data);
        if(response.data.success){
          //navigation.navigate('Success');
          //setPayfourId(response.data.data.payfourId);
          setIban(response.data.data.defaultBankAccountNumber);
          setLoading(false);
        }else{
          setLoading(false);
          console.log("NO SUCCESSS")
          console.log(response);
          Alert.alert(response.data.data.errors.message);
        }
      })
      .catch(error => {
        setLoading(false);
        console.error("Error sending data: ", error);
        console.error("Error sending data: ", error.response);
        console.error("Error sending data: ", error.response.data.errors.message);
        //console.log(JSON.parse(error.response));
        let msg="";
        (error.response.data.errors.message) ? msg += error.response.data.errors.message+"\n" : msg += "Ödeme hatası \n"; (error.response.data.errors.paymentError) ? msg += error.response.data.errors.paymentError+"\n" : msg += ""; Alert.alert(msg);

        
        //Alert.alert("Error sending data: ", error);
      });
    });
  }
  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', () => {  
        setTransactionType('all');    
        getPaymentData('week', 0);
      
    });
    return unsubscribe;
  }, [navigation]);
  const findVal = () => {
    console.log('findVal');
    console.log(selected);
    getPaymentData(selected);
  };
  
  const Item = ({amount, date, name, refno, category}) => (
    <View 
      key={refno}
      style={{
        borderRadius:16,
        height:72,
        width:'100%',
        backgroundColor:'#fff',
        padding:16,
        paddingRight:24,
        marginBottom:16,
      }}>
      <View style={{
        width:'100%',
        flexDirection:'row',
        justifyContent:'space-between',
        alignItems:'center',
      }}>
        <View style={{marginBottom:8}}>
          <View style={{
            width:'96%',
            flexDirection:'row',
            alignItems:'center',
            justifyContent:'space-between',
            marginBottom:8,
          }}>
            <Text style={{fontSize:12, color:'#0B1929'}}>
              {name}
            </Text>
            <Text style={{fontSize:14, color: category == 1 ? '#F85064' : '#004F97'}}>
              {category == 1 ? "-":"+"}{amount}
            </Text>
          </View>
          <View style={{
            width:'96%',
            flexDirection:'row',
            alignItems:'center',
            justifyContent:'space-between'
          }}>
            <Text style={{fontSize:12, color:'#909EAA'}}>
              Ref No: {refno}
            </Text>
            <Text style={{fontSize:12, color:'#909EAA'}}>
            {date}
            </Text>
          </View>
        </View>
        <TouchableOpacity style={{
          width: 24,
          height: 24,
        }}>
          <Image 
          source={require('../../assets/img/export/arrow_right_dark.png')}
          style={{
            width: 24,
            height: 24,
            resizeMode: 'contain',
          }}
          />
        </TouchableOpacity>
      </View>
      </View>
  );
  const renderItem = item => {
    return (
      <View
        style={{
          padding: 18,
          height: 54,
          color: '#1D1D25',
        }}>
        <Text
          style={{
            fontSize: 12,
            color: '#1D1D25',
          }}>
          {item.value}
        </Text>
      </View>
    );
  };
  const renderWallet = () => {
    if (walletData.length >0) {
      return (
        
        <FlatList
            data={walletData}
            ref={scrollRef}
            renderItem={({item}) => (
              <Item amount={item.amount} name={item.name} date={item.date} refno={item.refno} key={item.refno} category={item.category}/>
            )}
            keyExtractor={item => item.refno}
            style={{paddingLeft: 30,
              paddingRight: 30, marginLeft:-30, marginRight:-30}}
            onEndReached={setPage}
            initialNumToRender={20}
            
          />
      );
    } else {
      return (
        <View
          style={{
            padding: 18,
            height: 54,
            color: '#1D1D25',
          }}>
          <Text
            style={{
              fontSize: 14,
              color: '#0B1929',
              fontWeight: '700',
              paddingLeft: 20,
            }}>
            Bu tarihte herhangi bir işlem bulunamadı.
          </Text>
        </View>
      );
    }
  };
  return (
    <SafeAreaView style={{flex: 1, backgroundColor: '#fff'}}>
        <Modal
            animationType="slide"
            transparent={true}
            visible={filterModalVisible}
            onRequestClose={() => {
              setFilterModalVisible(!filterModalVisible);
            }}>
            <View
              style={{
                flex: 1,                
                justifyContent: 'flex-end',
                alignItems: 'flex-end',
                backgroundColor: 'rgba(92, 92, 92, 0.56)',
              }}>
              <View
                style={{
                  backgroundColor:'#fff',
                  borderTopLeftRadius: 24,
                  borderTopRightRadius: 24,
                  paddingTop: 16,
                  paddingBottom: 16,
                  paddingLeft: 16,
                  paddingRight: 16,
                  width: '100%',
                }}>
                  <View style={{
                    flexDirection:'row',
                    justifyContent:'flex-end',
                  }}>
                    <TouchableOpacity 
                      style={{
                        width:24,
                        height:24,
                      }}
                      onPress={() => {
                        console.log('close');
                        setFilterModalVisible(false);}}>                  
                        <Image 
                        source={require('../../assets/img/export/close.png')}
                        style={{
                          width: 24,
                          height: 24,
                          resizeMode: 'contain',
                        }}
                      />
                    </TouchableOpacity>
                  </View>
                  
                  <TouchableOpacity style={{
                    flexDirection:'row',
                    alignItems:'center',
                    paddingTop:8,
                    paddingBottom:8,
                    backgroundColor: filterType === 'today' ? '#F2F4F6' : '#fff'
                  }}
                  onPress={()=>setFilterType('today')}>
                    <View style={{
                      width:24, height:24, borderRadius:24, borderWidth:1, borderColor:'#004F97', marginRight:8,
                    }}
                    onPress={() => {
                      setFilterType('today');
                      console.log(filterType)
                      }}>
                        
                      <View style={{
                        width:12, 
                        height:12, 
                        borderRadius:12, 
                        backgroundColor:'#004F97', 
                        position:'absolute', 
                        top:5, 
                        left:5,
                        display: filterType === 'today' ? 'flex' : 'none'}}></View>
                    </View>
                      <Text style={{
                        fontSize:16,fontWeight:'700', color:'#004F97', marginBottom:4
                      }}>
                      Bugün
                      </Text>
                      
                  </TouchableOpacity>
                  <TouchableOpacity style={{
                    flexDirection:'row',
                    alignItems:'center',
                    paddingTop:8,
                    paddingBottom:8,
                    backgroundColor: filterType === 'yesterday' ? '#F2F4F6' : '#fff'
                  }}
                  onPress={()=>setFilterType('yesterday')}>
                    <View style={{
                      width:24, height:24, borderRadius:24, borderWidth:1, borderColor:'#004F97', marginRight:8,
                    }}
                    onPress={() => {
                      setFilterType('yesterday');
                      console.log(filterType);
                      }}>
                        
                      <View style={{
                        width:12, 
                        height:12, 
                        borderRadius:12, 
                        backgroundColor:'#004F97', 
                        position:'absolute', 
                        top:5, 
                        left:5,
                        display: filterType === 'yesterday' ? 'flex' : 'none'}}></View>
                    </View>
                      <Text style={{
                        fontSize:16,fontWeight:'700', color:'#004F97', marginBottom:4
                      }}>
                      Dün
                      </Text>
                      
                  </TouchableOpacity>
                  <TouchableOpacity style={{
                    flexDirection:'row',
                    alignItems:'center',
                    paddingTop:8,
                    paddingBottom:8,
                    backgroundColor: filterType === 'week' ? '#F2F4F6' : '#fff'
                  }}
                  onPress={()=>setFilterType('week')}>
                    <View style={{
                      width:24, height:24, borderRadius:24, borderWidth:1, borderColor:'#004F97', marginRight:8,
                    }}
                    onPress={() => {
                      setFilterType('week');
                      }}>
                        
                      <View style={{
                        width:12, 
                        height:12, 
                        borderRadius:12, 
                        backgroundColor:'#004F97', 
                        position:'absolute', 
                        top:5, 
                        left:5,
                        display: filterType === 'week' ? 'flex' : 'none'}}></View>
                    </View>
                      <Text style={{
                        fontSize:16,fontWeight:'700', color:'#004F97', marginBottom:4
                      }}>
                      Son 7 Gün
                      </Text>
                      
                  </TouchableOpacity>
                  <TouchableOpacity style={{
                    flexDirection:'row',
                    alignItems:'center',
                    paddingTop:8,
                    paddingBottom:8,
                    backgroundColor: filterType === 'twoweeks' ? '#F2F4F6' : '#fff'
                  }}
                  onPress={()=>setFilterType('twoweeks')}>
                    <View style={{
                      width:24, height:24, borderRadius:24, borderWidth:1, borderColor:'#004F97', marginRight:8,
                    }}
                    onPress={() => {
                      setFilterType('twoweeks');
                      }}>
                        
                      <View style={{
                        width:12, 
                        height:12, 
                        borderRadius:12, 
                        backgroundColor:'#004F97', 
                        position:'absolute', 
                        top:5, 
                        left:5,
                        display: filterType === 'twoweeks' ? 'flex' : 'none'}}></View>
                    </View>
                      <Text style={{
                        fontSize:16,fontWeight:'700', color:'#004F97', marginBottom:4
                      }}>
                      Son 15 Gün
                      </Text>
                      
                  </TouchableOpacity>
                  <TouchableOpacity style={{
                    flexDirection:'row',
                    alignItems:'center',
                    paddingTop:8,
                    paddingBottom:8,
                    backgroundColor: filterType === 'month' ? '#F2F4F6' : '#fff'
                  }}
                  onPress={()=>setFilterType('month')}>
                    <View style={{
                      width:24, height:24, borderRadius:24, borderWidth:1, borderColor:'#004F97', marginRight:8,
                    }}
                    onPress={() => {
                      setFilterType('month');
                      }}>
                        
                      <View style={{
                        width:12, 
                        height:12, 
                        borderRadius:12, 
                        backgroundColor:'#004F97', 
                        position:'absolute', 
                        top:5, 
                        left:5,
                        display: filterType === 'month' ? 'flex' : 'none'}}></View>
                    </View>
                      <Text style={{
                        fontSize:16,fontWeight:'700', color:'#004F97', marginBottom:4
                      }}>
                      Bu Ay
                      </Text>
                      
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={[
                      styles.buttonStyle,
                      {
                        width: '100%',
                        height: 52,
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        borderWidth: 2,
                        borderColor: '#004F97',
                        backgroundColor: '#004F97',
                        padding:0,
                      },
                    ]}
                    onPress={() => setFilterData(filterType)}>
                    <Text
                      style={{fontSize: 14, color: '#ffffff'}}>
                      Tamam
                    </Text>
                  </TouchableOpacity>
               
              </View>
            </View>
      </Modal> 
      
      <Loader loading={loading} />
      <SubtabHeader routetarget="discover" name="İşlemlerim" count="0" />
      <LinearGradient colors={['#d4dde9', '#ecedf2']} 
      style={{
        position:'absolute',
        width:'100%',
        height:'100%',
        top:60,
        zIndex:0,
        
      }}
      >
  
      </LinearGradient>
      <View style={{padding:16,}}>
        <View style={{borderRadius:16}}>
          
          <View style={{
            padding:8,
            borderTopLeftRadius:8,
            borderTopRightRadius:8,
            backgroundColor:'#fff',
            flexDirection:'row',
            justifyContent:'space-between',
            width:'100%'
          }}>
            <TouchableOpacity 
            style={{
              alignItems:'center', 
              justifyContent:'center',
              borderRadius:8,
              height:46,
              width:'33%',
              backgroundColor: transactionType==='all'? '#DFF0FF' : '#fff',
            }}
            onPress={()=>{
              setTransactionType('all');
              setFilterData(filterType);}
            }
            >
              <Text style={{
                fontSize:12,
                color: transactionType==='all'? '#004F97':'#909EAA',
              }}
              >
                Tümü
              </Text>
            </TouchableOpacity>
            <TouchableOpacity 
            style={{
              alignItems:'center', 
              justifyContent:'center',
              borderRadius:8,
              height:46,
              width:'33%',
              backgroundColor: transactionType==='waiting'? '#DFF0FF' : '#fff',
            }}
            onPress={()=>{
              setTransactionType('waiting');
              getPendings();
            }}
            >
              <Text style={{
                fontSize:12,
                color: transactionType==='waiting'? '#004F97':'#909EAA',
              }}
              >
                Bekleyen
              </Text>
            </TouchableOpacity>
            <TouchableOpacity 
            style={{
              alignItems:'center', 
              justifyContent:'center',
              borderRadius:8,
              height:46,
              width:'33%',
              backgroundColor: transactionType==='canceled'? '#DFF0FF' : '#fff',
            }}
            onPress={()=>
              {
                setTransactionType('canceled');
                setFilterData(filterType, true);}
              }
            >
              <Text style={{
                fontSize:12,
                color: transactionType==='canceled'? '#004F97':'#909EAA',
              }}
              >
                İptal Edilen
              </Text>
            </TouchableOpacity>

          </View>
          <View style={{
            flexDirection:'row',
            backgroundColor:'#F2F4F6',
            borderBottomLeftRadius:8,
            borderBottomRightRadius:8,
            padding:8,
            paddingLeft:16,
            borderTopWidth:1,
            borderTopColor:'#E4E4E8',
            alignItems:'center',
            justifyContent:'space-between'
          }}>
            <Text style={{
              color:'#0B1929',
              fontSize:12,
              fontWeight:'500',
            }}>
              Dönem Seçiniz
            </Text>
            <TouchableOpacity style={{
              width:160,
              height:32,
              borderRadius:4,
              backgroundColor:'#fff',
              padding:4,
              paddingLeft:16,
              flexDirection:'row',
              alignItems:'center',
              justifyContent:'space-between'
            }}
            onPress={()=> setFilterModalVisible(true)}
            >
              <Text style={{
                fontSize:12,
                color:'#909EAA'
              }}>
                {filterName}
              </Text>
              <Image 
              source={require('../../assets/img/export/arrow_down.png')}
              style={{
                width: 24,
                height: 24,
                resizeMode: 'contain',
              }}
            />
            </TouchableOpacity>
          </View>
        </View>
      </View>
      <View style={{
        paddingTop:12,
        paddingBottom:100,
        paddingLeft:16,
        paddingRight:16,
        flex:1,
        width:'100%',
      }}
      >
        {renderWallet()} 
      </View>  
         
    </SafeAreaView>
  );
};
const Waiting = ({route, navigation}) => {
  const [loading, setLoading] = useState(false);
  const [addModalVisible, setAddModalVisible] = useState(false);
  const [cashModalVisible, setCashModalVisible] = useState(false);
  const [iban, setIban] = useState('');
  const [payfourId, setPayfourId] = useState('');
  const [balance, setBalance] = useState('0,00');
  const [ibanModalVisible, setIbanModalVisible] = useState(false);
  const [successModalVisible, setSuccessModalVisible] = useState(false);
  const [showTooltip1, setShowTooltip1] = useState(false);
  const [showTooltip2, setShowTooltip2] = useState(false);
  const [showTooltip3, setShowTooltip3] = useState(false);
  useEffect(() => {
    const unsubscribe = navigation.addListener('focus', () => {
      console.log(">>>>>>>>>>>>>>> check waiting");
      console.log(route);
      console.log(route.params);
      console.log(navigation);

      setLoading(true);

    AsyncStorage.getItem('token').then(value =>{
      const config = {
        headers: { Authorization: `Bearer ${value}` }
      };
      console.log(value);
    axios.get('http://payfourapp.test.kodegon.com/api/account/getuser', config)
      .then(response => {
        console.log(response);
        console.log(response.data);
        if(response.data.success){
          //navigation.navigate('Success');
          setPayfourId(response.data.data.payfourId);
          setIban(response.data.data.defaultBankAccountNumber);
          setLoading(false);
          checkCurrentBalance();
        }else{
          setLoading(false);
          console.log("NO SUCCESSS")
          console.log(response);
          Alert.alert(response.data.data.errors.message);
        }
      })
      .catch(error => {
        setLoading(false);
        console.error("Error sending data: ", error);
        console.error("Error sending data: ", error.response);
        console.error("Error sending data: ", error.response.data.errors.message);
        //console.log(JSON.parse(error.response));
        let msg="";
        (error.response.data.errors.message) ? msg += error.response.data.errors.message+"\n" : msg += "Ödeme hatası \n"; (error.response.data.errors.paymentError) ? msg += error.response.data.errors.paymentError+"\n" : msg += ""; Alert.alert(msg);

        
        //Alert.alert("Error sending data: ", error);
      });
    });

    });
    return unsubscribe;
  }, [navigation]);
  const checkCurrentBalance = () => {
    AsyncStorage.getItem('token').then(value =>{
      const config = {
        headers: { Authorization: `Bearer ${value}` }
      };

      axios.get('http://payfourapp.test.kodegon.com/api/account/getbalance', config).then(response => {
        console.log(response.data);
        console.log(response.data.data);
        if(response.data.data.balance != null){
          let b = parseFloat(response.data.data.balance).toFixed(2).replace('.', ',');
          setBalance(b);
        }
        setLoading(false);
        if(route.params){
          if(route.params.payment) setAddModalVisible(true);
        }
      })
      .catch(error => {
        setLoading(false);
        console.error("Error sending data: ", error);
        let msg="";
        (error.response.data.errors.message) ? msg += error.response.data.errors.message+"\n" : msg += "Ödeme hatası \n"; (error.response.data.errors.paymentError) ? msg += error.response.data.errors.paymentError+"\n" : msg += ""; Alert.alert(msg);
      });

    });
  }
  const handleSubmitPress = () =>{
    setLoading(true);

    AsyncStorage.getItem('token').then(value =>{
      const config = {
        headers: { Authorization: `Bearer ${value}` }
      };
      console.log(value);
      let dataToSend ={
        paymentId:route.params.paymentId
      }
    console.log(dataToSend)
    axios.post('http://payfourapp.test.kodegon.com/api/payments/approvewithbalance', dataToSend, config)
      .then(response => {
        console.log(response);
        console.log(response.data);
        if(response.data.success){
          //navigation.navigate('Success');
          setSuccessModalVisible(true);
          setLoading(false);
        }else{
          setLoading(false);
          console.log("NO SUCCESSS")
          console.log(response);
          Alert.alert(response.data.data.errors.message);
        }
      })
      .catch(error => {
        setLoading(false);
        console.error("Error sending data: ", error);
        console.error("Error sending data: ", error.response);
        console.error("Error sending data: ", error.response.data.errors.message);
        //console.log(JSON.parse(error.response));
        let msg="";
        (error.response.data.errors.message) ? msg += error.response.data.errors.message+"\n" : msg += "Ödeme hatası \n"; (error.response.data.errors.paymentError) ? msg += error.response.data.errors.paymentError+"\n" : msg += ""; Alert.alert(msg);

        
        //Alert.alert("Error sending data: ", error);
      });
    });
  }

  return(
    <SafeAreaView style={{flex: 1, backgroundColor: '#fff'}}>
      
      <Modal
            animationType="slide"
            transparent={true}
            visible={addModalVisible}
            onRequestClose={() => {
              setAddModalVisible(!addModalVisible);
            }}>
            <View
              style={{
                flex: 1,                
                justifyContent: 'flex-end',
                alignItems: 'flex-end',
                backgroundColor: 'rgba(0, 79, 151, 0.6)',
              }}>
              <View
                style={{
                  backgroundColor:'#fff',
                  borderTopLeftRadius: 24,
                  borderTopRightRadius: 24,
                  paddingTop: 68,
                  paddingBottom: 16,
                  paddingLeft: 16,
                  paddingRight: 16,
                  width: '100%',
                }}>
                  <View style={{
                      marginBottom:16,
                      }}>
                        <Text style={{
                          fontSize:16,
                          fontWeight:'700',
                          color:'#004F97',
                          lineHeight:20,
                          textAlign:'center',
                        }}>
                          Para Yükle
                        </Text>
                        <Text style={{
                          fontSize:14,
                          lineHeight:20,
                          color:'#909eaa',
                          paddingLeft:24,
                          paddingRight:24,
                          textAlign:'center',
                          marginBottom:26,
                        }}>
                          Cüzdana para yüklemek için yükleme yöntemini seçiniz.
                      </Text>
                      <View style={{
                        padding:16,
                        borderRadius:8,
                        borderColor:'#E4E4E8',
                        borderWidth:1,
                        marginBottom:12,
                      }}>
                        <TouchableOpacity                            
                            onPress={() => {
                              setAddModalVisible(false);
                              setCashModalVisible(true);}}>
                        <View style={{
                          flexDirection:'row',
                          alignItems:'center',
                          justifyContent:'space-between',
                          paddingBottom:8,                          
                        }}>
                          <View style={{
                            flexDirection:'row',
                            alignItems:'center',
                          }}>
                            <Image
                              source={require('../../assets/img/export/add_register.png')}
                              style={{
                                width: 24,
                                height: 24,
                                resizeMode: 'contain',
                                marginRight:8,
                              }}
                            />
                            <Text style={{
                              fontSize:14,
                              color:'#004F97',
                            }}>
                              Kasadan Para Yükle
                            </Text>
                          </View>
                          
                            <Image
                                source={require('../../assets/img/export/arrow_right_dark.png')}
                                style={{
                                  width: 24,
                                  height: 24,
                                  resizeMode: 'contain',
                                }}
                              />
                          
                      </View>
                      </TouchableOpacity>
                        <Text style={{
                          fontSize:14,
                          color:'#909eaa',
                          borderTopWidth:1,
                          borderTopColor:'#E4E4E8',
                          paddingTop:8,
                        }}>
                          Kasadan para yüklemek için kasadaki görevliye payfour bilgilerinizi veriniz.
                        </Text>
                      </View>
                      <View style={{
                        padding:16,
                        borderRadius:8,
                        borderColor:'#E4E4E8',
                        borderWidth:1,
                        marginBottom:12,
                      }}>
                        
                        <TouchableOpacity
                            
                            onPress={() => {
                              setAddModalVisible(false);
                              setIbanModalVisible(true);}}>
                        <View style={{
                          flexDirection:'row',
                          alignItems:'center',
                          justifyContent:'space-between',
                          paddingBottom:8,                          
                        }}>
                          
                          <View style={{
                            flexDirection:'row',
                            alignItems:'center',
                          }}>
                            <Image
                              source={require('../../assets/img/export/add_iban.png')}
                              style={{
                                width: 24,
                                height: 24,
                                resizeMode: 'contain',
                                marginRight:8,
                              }}
                            />
                            <Text style={{
                              fontSize:14,
                              color:'#004F97',
                            }}>
                              Havale / EFT ile Yükle
                            </Text>
                          </View>
                          
                            <Image
                                source={require('../../assets/img/export/arrow_right_dark.png')}
                                style={{
                                  width: 24,
                                  height: 24,
                                  resizeMode: 'contain',
                                }}
                              />
                          
                      </View>
                      </TouchableOpacity>
                        <Text style={{
                          fontSize:14,
                          color:'#909eaa',
                          borderTopWidth:1,
                          borderTopColor:'#E4E4E8',
                          paddingTop:8,
                        }}>
                          Belirtilen IBAN numarasına EFT\Havale yoluyla para göndererek para yükleyebilirsiniz.
                        </Text>
                      </View>
                      <View style={{
                        padding:16,
                        borderRadius:8,
                        borderColor:'#E4E4E8',
                        borderWidth:1,
                      }}>
                        <TouchableOpacity
                            
                            onPress={null}>
                        <View style={{
                          flexDirection:'row',
                          alignItems:'center',
                          justifyContent:'space-between',
                          paddingBottom:8,                          
                        }}>
                          <View style={{
                            flexDirection:'row',
                            alignItems:'center',
                          }}>
                            <Image
                              source={require('../../assets/img/export/add_masterpass.png')}
                              style={{
                                width: 24,
                                height: 24,
                                resizeMode: 'contain',
                                marginRight:8,
                              }}
                            />
                            <Text style={{
                              fontSize:14,
                              color:'#004F97',
                            }}>
                              Masterpass ile Yükle
                            </Text>
                          </View>
                          
                            <Image
                                source={require('../../assets/img/export/arrow_right_dark.png')}
                                style={{
                                  width: 24,
                                  height: 24,
                                  resizeMode: 'contain',
                                }}
                              />
                          
                      </View>
                      </TouchableOpacity>
                        <Text style={{
                          fontSize:14,
                          color:'#909eaa',
                          borderTopWidth:1,
                          borderTopColor:'#E4E4E8',
                          paddingTop:8,
                        }}>
                          Masterpass’e kayıtlı kredi ya da banka kartı bilgilerin ile hızlıca para yükleyebilirsiniz.
                        </Text>
                      </View>
                  </View>
                  
                
                <TouchableOpacity
                  style={[
                    styles.buttonStyle,
                    {
                      width: '100%',
                      height: 52,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      borderWidth: 2,
                      borderColor: '#004F97',
                      backgroundColor: '#004F97',
                      padding:0,
                    },
                  ]}
                  onPress={() => setAddModalVisible(false)}>
                  <Text
                    style={{fontSize: 14, color: '#ffffff'}}>
                    Kapat
                  </Text>
                </TouchableOpacity>
               
              </View>
            </View>
      </Modal>
      <Modal
            animationType="slide"
            transparent={true}
            visible={cashModalVisible}
            onRequestClose={() => {
              setCashModalVisible(!cashModalVisible);
            }}>
            <View
              style={{
                flex: 1,                
                justifyContent: 'flex-end',
                alignItems: 'flex-end',
                backgroundColor: 'rgba(0, 79, 151, 0.6)',
              }}>
              <View
                style={{
                  backgroundColor:'#fff',
                  borderTopLeftRadius: 24,
                  borderTopRightRadius: 24,
                  paddingTop: 16,
                  paddingBottom: 16,
                  paddingLeft: 16,
                  paddingRight: 16,
                  width: '100%',
                }}>
                  
                  <View style={{
                    paddingTop:24,
                    paddingBottom:24,
                    alignItems:'center',
                    justifyContent:'center',
                  }}>
                    <Image 
                        source={require('../../assets/img/export/payfourid_icon.png')}
                        style={{
                          width: 93,
                          height: 93,
                          resizeMode: 'contain',
                          marginBottom:14,
                        }}
                        />
                  </View>
                  <View style={{
                      marginBottom:24,
                      }}>
                        <Text style={{
                          fontSize:20,
                          fontWeight:'700',
                          color:'#004F97',
                          marginBottom:16,
                          textAlign:'center',
                        }}>
                          Payfour ile hem online 
                          hem de kasada
                          ödeme yapabilirsiniz!
                        </Text>
                        <Text style={{
                          fontSize:16,
                          lineHeight:20,
                          color:'#004F97',
                          paddingLeft:24,
                          paddingRight:24,
                          textAlign:'center',
                          marginBottom:26,
                        }}>
                          Mağazalarımızdan veya CarrefourSa'ya ait online platformlardan yapacağınız alışverişlerinizi Payfour ile ödemek için aşağıdaki Payfour numarasını veya telefon numaranızı kasiyere söylemeniz veya platformlardaki ilgili alana girmeniz yeterli olacaktır.
                      </Text>
                      <View style={{
                        padding:16,
                        borderRadius:8,
                        backgroundColor:'#F2F4F6',
                        flexDirection:'row',
                        alignItems:'center',
                        justifyContent:'center',
                      }}>
                        <Text style={{
                          fontSize:16,
                          color:'#0B1929',
                        }}>
                          Payfour ID:
                        </Text>
                        <Text style={{
                          fontSize:16,
                          color:'#004F97',
                        }}>
                          {payfourId}
                        </Text>
                      </View>
                  </View>
                  
                
                <TouchableOpacity
                  style={[
                    styles.buttonStyle,
                    {
                      width: '100%',
                      height: 52,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      borderWidth: 2,
                      borderColor: '#004F97',
                      backgroundColor: '#004F97',
                      padding:0,
                    },
                  ]}
                  onPress={() => setCashModalVisible(false)}>
                  <Text
                    style={{fontSize: 14, color: '#ffffff'}}>
                    Kapat
                  </Text>
                </TouchableOpacity>
               
              </View>
            </View>
      </Modal>
      <Modal
            animationType="slide"
            transparent={true}
            visible={ibanModalVisible}
            onRequestClose={() => {
              setIbanModalVisible(!ibanModalVisible);
            }}>
            <View
              style={{
                flex: 1,                
                justifyContent: 'flex-end',
                alignItems: 'flex-end',
                backgroundColor: 'rgba(0, 79, 151, 0.6)',
              }}>
              <View
                style={{
                  backgroundColor:'#fff',
                  borderTopLeftRadius: 24,
                  borderTopRightRadius: 24,
                  paddingTop: 16,
                  paddingBottom: 16,
                  paddingLeft: 16,
                  paddingRight: 16,
                  width: '100%',
                }}>
                  
                  <View style={{
                    paddingTop:24,
                    paddingBottom:24,
                    alignItems:'center',
                    justifyContent:'center',
                  }}>
                    <Image 
                        source={require('../../assets/img/export/payfoureft_icon.png')}
                        style={{
                          width: 93,
                          height: 93,
                          resizeMode: 'contain',
                          marginBottom:14,
                        }}
                        />
                  </View>
                  <View style={{
                      marginBottom:24,
                      }}>
                        <Text style={{
                          fontSize:20,
                          fontWeight:'700',
                          color:'#004F97',
                          marginBottom:16,
                          textAlign:'center',
                        }}>
                          Havale / EFT Para yükleme bilgileri
                        </Text>
                        <Text style={{
                          fontSize:12,
                          color:'#909EAA',
                          paddingLeft:24,
                          paddingRight:24,
                          textAlign:'center',
                          marginBottom:26,
                        }}>
                          Payfour hesabına para yüklemek için, bankacılık uygulamanıza giriş yaparak size ait banka hesabınız üzerinden aşağıda yer alan hesap bilgilerini kullanarak yükleme yapabilirsiniz.
                      </Text>
                      <Text style={{
                          fontSize:14,
                          fontWeight:'700',
                          color:'#004F97',
                          marginBottom:8,
                          textAlign:'left',
                        }}>
                          Vakıfbank
                        </Text>
                        <View style={[regstyles.registerInputStyle, {borderColor: '#EBEBEB', paddingBottom:10, paddingTop:28,}]}>                       
                      <Text style={{                                           
                          fontSize: 12,
                          lineHeight:12, 
                          padding:0,
                          color: '#909EAA', 
                          position:'absolute',
                          top:14,                     
                          left:14
                      }}>
                        IBAN numarası
                      </Text>
                      <Text
                        style={{                      
                          fontSize: 14,
                          padding:0,
                          color: '#0B1929',
                        }}
                      >
                        TR810001500158007331469750
                      </Text>
                      <TouchableOpacity style={{
                        width:30,
                        height:30,
                        alignItems:'center',
                        justifyContent:'center',
                        position:'absolute',
                        right:10,
                        top:'90%'
                      }}
                      onPress={()=> {
                        Clipboard.setString('TR810001500158007331469750')
                        setShowTooltip1(true);
                        setTimeout(function(){
                          setShowTooltip1(false);
                        }, 3000);
                      }}>
                        <View style={{
                          position:'absolute',
                          backgroundColor:'#004F97',
                          borderRadius:8,
                          width:65,
                          alignItems:'center',
                          justifyContent:'center',
                          padding:4,
                          top:-24,
                          display: showTooltip1 ? 'flex':'none',
                        }}>
                          <Text style={{color:'#fff', fontSize:11}}>Kopyalandı</Text>
                        </View>
                        <Image 
                        source={require('../../assets/img/export/copytoclipboard.png')}
                        style={{
                          width: 16,
                          height: 16,
                          resizeMode: 'contain',
                        }}
                      />
                      </TouchableOpacity>
                    </View>
                    <View style={[regstyles.registerInputStyle, {borderColor: '#EBEBEB', paddingBottom:10,paddingTop:28,}]}>                       
                      <Text style={{                                           
                          fontSize: 12,
                          lineHeight:12, 
                          padding:0,
                          color: '#909EAA', 
                          position:'absolute',
                          top:14,                     
                          left:14
                      }}>
                        Alıcı hesap Adı
                      </Text>
                      <Text
                        style={{                      
                          fontSize: 14,
                          padding:0,
                          color: '#0B1929',
                          width:'80%'
                        }}
                      >
                        CarrefourSA Carrefour Sabancı Ticaret Merkezi A.Ş.
                      </Text>
                      <TouchableOpacity style={{
                        width:30,
                        height:30,
                        alignItems:'center',
                        justifyContent:'center',
                        position:'absolute',
                        right:10,
                        top:'70%'
                      }}
                      onPress={()=> {Clipboard.setString('CarrefourSA Carrefour Sabancı Ticaret Merkezi A.Ş.')
                        setShowTooltip2(true);
                        setTimeout(function(){
                          setShowTooltip2(false);
                        }, 3000);
                      }}>
                        <View style={{
                          position:'absolute',
                          backgroundColor:'#004F97',
                          borderRadius:8,
                          width:65,
                          alignItems:'center',
                          justifyContent:'center',
                          padding:4,
                          top:-24,
                          display: showTooltip2 ? 'flex':'none',
                        }}>
                          <Text style={{color:'#fff', fontSize:11}}>Kopyalandı</Text>
                        </View>
                        <Image 
                        source={require('../../assets/img/export/copytoclipboard.png')}
                        style={{
                          width: 16,
                          height: 16,
                          resizeMode: 'contain',
                        }}
                      />
                      </TouchableOpacity>
                    </View>
                    <View style={[regstyles.registerInputStyle, {borderColor: '#EBEBEB', paddingBottom:10,paddingTop:28,}]}>                       
                      <Text style={{                                           
                          fontSize: 12,
                          lineHeight:12, 
                          padding:0,
                          color: '#909EAA', 
                          position:'absolute',
                          top:14,                     
                          left:14
                      }}>
                        Açıklama
                      </Text>
                      <Text
                        style={{                      
                          fontSize: 14,
                          padding:0,
                          color: '#0B1929',
                          width:'80%'
                        }}
                      >
                        {iban}
                      </Text>
                      <TouchableOpacity style={{
                        width:30,
                        height:30,
                        alignItems:'center',
                        justifyContent:'center',
                        position:'absolute',
                        right:10,
                        top:'90%'
                      }}
                      onPress={()=> {Clipboard.setString(iban)
                        setShowTooltip3(true);
                        setTimeout(function(){
                          setShowTooltip3(false);
                        }, 3000);
                      }}>
                        <View style={{
                          position:'absolute',
                          backgroundColor:'#004F97',
                          borderRadius:8,
                          width:65,
                          alignItems:'center',
                          justifyContent:'center',
                          padding:4,
                          top:-24,
                          display: showTooltip3 ? 'flex':'none',
                        }}>
                          <Text style={{color:'#fff', fontSize:11}}>Kopyalandı</Text>
                        </View>
                        <Image 
                        source={require('../../assets/img/export/copytoclipboard.png')}
                        style={{
                          width: 16,
                          height: 16,
                          resizeMode: 'contain',
                        }}
                      />
                      </TouchableOpacity>
                    </View>
                      {/* <View style={{
                        padding:16,
                        borderRadius:8,
                        backgroundColor:'#F2F4F6',
                        flexDirection:'row',
                        alignItems:'center',
                        justifyContent:'center',
                      }}>
                        <Text style={{
                          fontSize:16,
                          color:'#0B1929',
                        }}>
                        </Text>
                        <Text style={{
                          fontSize:16,
                          color:'#004F97',
                        }}>
                          {iban}
                        </Text>
                      </View> */}
                  </View>
                  
                
                <TouchableOpacity
                  style={[
                    styles.buttonStyle,
                    {
                      width: '100%',
                      height: 52,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      borderWidth: 2,
                      borderColor: '#004F97',
                      backgroundColor: '#004F97',
                      padding:0,
                    },
                  ]}
                  onPress={() => setIbanModalVisible(false)}>
                  <Text
                    style={{fontSize: 14, color: '#ffffff'}}>
                    Kapat
                  </Text>
                </TouchableOpacity>
               
              </View>
            </View>
      </Modal>
      <Modal
          animationType="slide"
          transparent={true}
          visible={successModalVisible}
          onRequestClose={() => {
            Alert.alert('Modal has been closed.');
            setSuccessModalVisible(!successModalVisible);
          }}>
            <View style={{flex: 1, backgroundColor: '#004F97'}}>
          <SubtabHeader routetarget="discover" name="Keşfet" count="0" mode="dark"/>
          
      <View style={{paddingTop:136, marginBottom:60, alignItems:'center'}}>
          <Image
            source={require('../../assets/img/export/payment_top_white.png')}
            style={{
              width: 311,
              height: 56,
              resizeMode:'contain',
            }}
          />
      </View>
      <View style={{
        justifyContent:'center',
        alignItems:'center',
        flexDirection:'column',
      }}>
        <Image
          source={require('../../assets/img/export/payfour_logo_w.png')}
          style={{
            width: 119,
            height: 42,
            resizeMode:'contain',
            marginBottom:4,
          }}
        />
        <Text style={{fontSize:32, color:'#fff', textAlign:'center'}}>
          Teşekkürler!
        </Text>
      </View>
      <View style={{
        borderTopLeftRadius:24,
        borderTopRightRadius:24,
        backgroundColor:'#fff',
        paddingTop:32,
        paddingBottom:32,
        paddingLeft:16,
        paddingRight:16,
        position:'absolute',
        bottom:0,
        width:'100%'

      }}>
        <View style={{alignItems:'center', marginBottom:16}}>
          <Image
              source={require('../../assets/img/export/payment_success.png')}
              style={{
                width: 80,
                height: 80,
                resizeMode:'contain',
              }}
          />
        </View>
        <View>
        <Text style={{fontSize:16, color:'#004F97', textAlign:'center', fontWeight:'500', marginBottom:16}}>
          Ödemeniz başarılı bir şekilde gerçekleşti
        </Text>
        <Text style={{fontSize:14, color:'#909EAA', textAlign:'center', marginBottom:24}}>
          Dilerseniz bir sonraki alışverişiniz için önceden hazır limitinizi öğrenebilir ve kasa işlemlerini kısa sürede tamamlayabilirsiniz.
        </Text>
        
        </View>
        <TouchableOpacity
          style={[regstyles.buttonStyle, {padding:0, marginLeft:0,marginRight:0, marginBottom: 10, backgroundColor: '#004F97', flex:1}]}              
          activeOpacity={0.5}
          onPress={()=>{
            console.log("close success");
            setSuccessModalVisible(false);
            navigation.navigate('Balance');
            }}>
          <Text style={regstyles.buttonTextStyle}>Kapat</Text>
        </TouchableOpacity>
      </View>
      </View>
      </Modal>
      <Loader loading={loading} />
      <SubtabHeader routetarget="Balance" name="Ödeme İşlemi" count="0" />
      <LinearGradient colors={['#d4dde9', '#ecedf2']} 
      style={{
        position:'absolute',
        width:'100%',
        height:'100%',
        top:60,
        zIndex:0,
        
      }}
      >
  
      </LinearGradient>
      <ScrollView style={{
        paddingTop:12,
        paddingBottom:12,
        paddingLeft:16,
        paddingRight:16,
        flex:1,
        width:'100%',
      }}>
      <View style={{}}>
        <View style={{
          borderRadius:16,
          paddingLeft:16,
          paddingRight:16,
          paddingTop:24,
          paddingBottom:24,
          backgroundColor:'#fff',
          alignItems:'center',
          marginBottom:16,
          }}>
          <Image
            source={require('../../assets/img/export/payment_top_blue.png')}
            style={{
              width: 311,
              height: 56,
              resizeMode: 'contain',
              marginBottom:4,
            }}
          />
          <Text style={{
            fontSize:16,
            color:'#0B1929',
            marginBottom:12,
            textAlign:'center',
          }}>
            Merhaba,
          </Text>
          <View style={{
            borderRadius:4,
            backgroundColor:'#F2F4F6',
            padding:8,
            flexDirection:'row',
            alignItems:'center',
            justifyContent:'center',
          }}>
            <Text style={{
              fontSize:16,
              color:'#0B1929'
            }}>
              Payfour ID:
            </Text>
            <Text style={{
              fontSize:16,
              color:'#004F97'
            }}>
              {payfourId}
            </Text>
          </View>
        </View>

        <View style={{
          borderRadius:16,
          paddingLeft:16,
          paddingRight:16,
          paddingTop:24,
          paddingBottom:24,
          backgroundColor:'#fff',
          alignItems:'center',
          marginBottom:16,
          }}>
            <Text style={{fontSize:14,fontWeight:'700', textAlign:'center', color:'#4c4c4c'}}>
              {route.params.storeName? route.params.storeName : route.params.storeCode}
            </Text>
            <Text style={{fontSize:14, textAlign:'center', color:'#4c4c4c', marginBottom:32, paddingLeft:24, paddingRight:24,}}>
              mağazasından alışveriş yaptığınız için teşekkür ederiz.
            </Text>
            <Text style={{fontSize:18,fontWeight:'700', textAlign:'center', color:'#004F97'}}>
              Ödenecek Tutar
            </Text>
            <View style={{
              flexDirection:'row',
              alignItems:'flex-start',
              justifyContent:'center',
              marginBottom:15,
            }}>
              <Text style={{fontSize:32,fontWeight:'700', textAlign:'center', color:'#004F97'}}>
                {route.params.amount}
              </Text>
              <Text style={{fontSize:16,fontWeight:'700', textAlign:'center', color:'#004F97', paddingTop:5}}>
                TL
              </Text>
            </View>
        </View>
          <View style={{

          }}>
            <Text style={{fontSize:14,fontWeight:'700', textAlign:'center', color:'#4c4c4c',marginBottom:16,}}>
              Ödeme Yöntemi
            </Text>
        </View>
        <View style={{
          backgroundColor:'#fff',
          borderRadius:8,
          padding:12,
          marginBottom:10,
          flexDirection:'row',
          justifyContent:'space-between',
          alignItems:'center',
        }}>
          <View style={{
            flexDirection:'row',
            alignItems:'center',
          }}>
            <TouchableOpacity style={{
              width:24, height:24, borderRadius:24, borderWidth:1, borderColor:'#004F97', marginRight:8,
            }}>
              <View style={{width:12, height:12, borderRadius:12, backgroundColor:'#004F97', position:'absolute', top:5, left:5}}></View>
            </TouchableOpacity>
            <View style={{}}>
              <Text style={{
                fontSize:16,fontWeight:'700', color:'#004F97', marginBottom:4
              }}>
              Cüzdan ile
              </Text>
              <Text style={{
                fontSize:12,
                color:'#909EAA',
              }}>
                Bakiye: {balance} TL
              </Text>
            </View>
          </View>
          <TouchableOpacity style={{
            justifyContent:'center',
            alignItems:'center',
            borderRadius:6,
            borderWidth:1,
            borderColor:'#004F97',
            height:40,
            width:115
          }}
          onPress={() =>setAddModalVisible(true)}>
            <Text style={{fontSize:12, color:'#004F97'}}>
              +  Para Yükle
            </Text>
          </TouchableOpacity>
        </View>
        <View style={{
          backgroundColor:'#fff',
          borderRadius:8,
          padding:12,
          marginBottom:10,
          flexDirection:'row',
          justifyContent:'space-between',
          alignItems:'center',
        }}>
          <View style={{
            flexDirection:'row',
            alignItems:'center',
          }}>
            <TouchableOpacity style={{
              width:24, height:24, borderRadius:24, borderWidth:1, borderColor:'#004F97', marginRight:8,
            }}>
              {/* <View style={{width:12, height:12, borderRadius:12, backgroundColor:'#004F97', position:'absolute', top:5, left:5}}></View> */}
            </TouchableOpacity>
            <View style={{}}>
              <Text style={{
                fontSize:16,fontWeight:'700', color:'#004F97', marginBottom:4
              }}>
              Alışveriş Kredisi ile
              </Text>
              <Text style={{
                fontSize:12,
                color:'#909EAA',
              }}>
                5.000 TL ön onaylı kredi
              </Text>
            </View>
          </View>
          <TouchableOpacity style={{
            justifyContent:'center',
            alignItems:'center',
            borderRadius:6,
            borderWidth:1,
            borderColor:'#004F97',
            height:40,
            width:115
          }}>
            <Text style={{fontSize:12, color:'#004F97'}}>
              Limitini Öğren
            </Text>
          </TouchableOpacity>
        </View>       
      </View>
      <TouchableOpacity
          style={[regstyles.buttonStyle, {padding:0, marginLeft:0,marginRight:0, marginBottom: 120, backgroundColor: '#004F97', flex:1}]}              
          activeOpacity={0.5}
          onPress={handleSubmitPress}>
          <Text style={regstyles.buttonTextStyle}>Öde</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  )

}
const Success = ({route, navigation}) => {
  
  return (
    <SafeAreaView style={{flex: 1, backgroundColor: '#004F97'}}>
      <SubtabHeader routetarget="discover" name="Keşfet" count="0" mode="dark"/>
      <View style={{paddingTop:136, marginBottom:60, alignItems:'center'}}>
          <Image
            source={require('../../assets/img/export/payment_top_white.png')}
            style={{
              width: 311,
              height: 56,
              resizeMode:'contain',
            }}
          />
      </View>
      <View style={{
        justifyContent:'center',
        alignItems:'center',
        flexDirection:'column',
      }}>
        <Image
          source={require('../../assets/img/export/payfour_logo_w.png')}
          style={{
            width: 119,
            height: 42,
            resizeMode:'contain',
            marginBottom:4,
          }}
        />
        <Text style={{fontSize:32, color:'#fff', textAlign:'center'}}>
          Teşekkürler!
        </Text>
      </View>
    </SafeAreaView>
  )
}
const regstyles = StyleSheet.create({
  registerInputStyle:{
    backgroundColor:'#fff',
    paddingTop:17,
    paddingBottom:17, 
    paddingLeft:12, 
    paddingRight:12,    
    borderWidth: 1,
    borderRadius: 10,
    marginBottom:16,
  },
  mainBody: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ffffff',
    alignContent: 'center',
  },
  topStyle: {
    alignContent: 'center',
    paddingTop: 39,
    paddingBottom: 30,
    borderColor: '#EBEBEB',
    borderBottomWidth: 1,
  },
  centerStyle: {
    alignContent: 'center',
  },
  sectionStyle: {
    flexDirection: 'column',
    marginTop: 20,
    marginLeft: 35,
    marginRight: 35,
    margin: 10,
  },
  buttonStyle: {
    backgroundColor: '#1D1D25',
    borderWidth: 0,
    color: '#FFFFFF',
    height: 65,
    alignItems: 'center',
    borderRadius: 10,
    marginLeft: 35,
    marginRight: 35,
    marginBottom: 25,
  },
  buttonTextStyle: {
    color: '#FFFFFF',
    paddingVertical: 20,
    fontFamily: 'Helvetica-Bold',
    fontWeight: 'bold',
    fontSize: 16,
  },
  inputTitleStyle: {
    color: '#7E797F',
    fontSize: 12,
    marginBottom: 10,
  },
  inputStyle: {
    color: '#1D1D25',
    paddingTop: 30,
    paddingBottom: 30,
    fontFamily: 'Helvetica-Bold',
    fontSize: 14,
    borderWidth: 1,
    borderColor: '#EBEBEB',
    borderLeftWidth: 0,
    borderRightWidth: 0,
    marginBottom: 48,
    opacity: 1,
  },
  bottomStyle: {
    alignItems: 'center',
    marginBottom: 30,
  },
  copyrightTextStyle: {
    color: '#7E797F',
    textAlign: 'center',
    fontWeight: 'light',
    fontSize: 10,
    alignSelf: 'center',
  },
  errorTextStyle: {
    color: 'red',
    textAlign: 'center',
    fontSize: 14,
  },
});
const WalletScreen = ({navigation}) => {
  // useEffect(() => {
  //   const unsubscribe = navigation.addListener('focus', () => {
  //     navigation.navigate('Balance');
  //   });
  //   return unsubscribe;
  // }, [navigation]);

  return (
    <Stack.Navigator initialRouteName="Balance">
      <Stack.Screen
        name="Balance"
        component={Balance}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="Waiting"
        component={Waiting}
        options={{headerShown: false}}
      />
      <Stack.Screen
        name="Success"
        component={Success}
        options={{headerShown: false}}
      />
      
    </Stack.Navigator>
  );
};

export default WalletScreen;


